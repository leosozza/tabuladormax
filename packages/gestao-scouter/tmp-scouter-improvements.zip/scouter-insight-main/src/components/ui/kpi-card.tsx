import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface KPICardProps {
  title: string;
  value: string | number;
  trend?: number;
  format?: 'number' | 'percentage' | 'currency';
  variant?: 'default' | 'elite' | 'forte' | 'warning' | 'danger';
  subtitle?: string;
  icon?: React.ReactNode;
  loading?: boolean;
}

export function KPICard({
  title,
  value,
  trend,
  format = 'number',
  variant = 'default',
  subtitle,
  icon,
  loading = false
}: KPICardProps) {
  const formatValue = (val: string | number) => {
    if (loading) return '...';
    
    const numVal = typeof val === 'string' ? parseFloat(val) : val;
    if (isNaN(numVal)) return val.toString();

    switch (format) {
      case 'percentage':
        return `${numVal.toFixed(1)}%`;
      case 'currency':
        return new Intl.NumberFormat('pt-BR', {
          style: 'currency',
          currency: 'BRL'
        }).format(numVal);
      default:
        return new Intl.NumberFormat('pt-BR').format(numVal);
    }
  };

  const getTrendIcon = () => {
    if (!trend || trend === 0) return <Minus className="h-4 w-4" />;
    return trend > 0 ? 
      <TrendingUp className="h-4 w-4 text-success" /> : 
      <TrendingDown className="h-4 w-4 text-error" />;
  };

  const getTrendText = () => {
    if (!trend || trend === 0) return 'Sem alteração';
    const sign = trend > 0 ? '+' : '';
    return `${sign}${trend.toFixed(1)}%`;
  };

  const cardVariants = {
    default: 'kpi-card',
    elite: 'kpi-card-elite',
    forte: 'kpi-card-forte', 
    warning: 'kpi-card-warning',
    danger: 'kpi-card-danger',
  };

  return (
    <Card className={cn(cardVariants[variant])}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        {icon && (
          <div className="text-muted-foreground">
            {icon}
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          <div className={cn(
            "text-2xl font-bold tracking-tight",
            loading && "animate-pulse"
          )}>
            {formatValue(value)}
          </div>
          
          {subtitle && (
            <p className="text-xs text-muted-foreground">
              {subtitle}
            </p>
          )}
          
          {trend !== undefined && (
            <div className="flex items-center space-x-1 text-xs">
              {getTrendIcon()}
              <span className={cn(
                "font-medium",
                trend > 0 && "text-success",
                trend < 0 && "text-error",
                trend === 0 && "text-muted-foreground"
              )}>
                {getTrendText()}
              </span>
              <span className="text-muted-foreground">vs período anterior</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}