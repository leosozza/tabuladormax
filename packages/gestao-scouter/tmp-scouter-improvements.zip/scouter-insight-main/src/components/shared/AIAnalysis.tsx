import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Brain, TrendingUp, AlertTriangle, CheckCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface AIAnalysisProps {
  scouterId?: string;
  scouterName?: string;
  projectId?: string;
  projectName?: string;
  filters?: any;
}

interface AnalysisResult {
  panorama: string;
  pontos_fortes: string[];
  pontos_atenção: string[];
  recomendações: string[];
  score_geral: number;
  classificação: 'Elite' | 'Forte' | 'Estável' | 'Em desenvolvimento' | 'Atenção';
}

export function AIAnalysis({ scouterId, scouterName, projectId, projectName, filters }: AIAnalysisProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);

  const handleAnalyze = async () => {
    if (!scouterId && !projectId) {
      toast.error("Selecione um scouter ou projeto para análise");
      return;
    }

    setIsAnalyzing(true);
    
    try {
      // Simular análise (será substituído pela integração real com IA)
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Mock da análise - será substituído pela chamada real da API
      const mockAnalysis: AnalysisResult = {
        panorama: scouterId 
          ? `O scouter ${scouterName} apresenta performance sólida com taxa de conversão de 68% e boa velocidade de confirmação. Destaque para o volume de prospecção acima da média.`
          : `O projeto ${projectName} mostra indicadores equilibrados com margem para otimização na taxa de comparecimento e qualidade das fotos.`,
        pontos_fortes: scouterId 
          ? ["Alto volume de prospecção", "Boa taxa de confirmação", "Velocidade adequada de resposta"]
          : ["Taxa de interesse elevada", "Boa cobertura geográfica", "Equipe engajada"],
        pontos_atenção: scouterId
          ? ["Taxa de comparecimento pode melhorar", "Qualidade das fotos inconsistente"]
          : ["Taxa de comparecimento abaixo do ideal", "Concentração excessiva em algumas regiões"],
        recomendações: scouterId
          ? ["Focar em melhorar a taxa de comparecimento", "Implementar checklist de qualidade para fotos", "Criar incentivos para confirmações mais rápidas"]
          : ["Implementar treinamento focado em agendamento", "Expandir cobertura para novas regiões", "Criar programa de mentoria entre scouters"],
        score_geral: Math.floor(Math.random() * 40) + 60,
        classificação: 'Forte'
      };
      
      setAnalysis(mockAnalysis);
      toast.success("Análise de IA concluída com sucesso!");
      
    } catch (error) {
      toast.error("Erro ao gerar análise de IA");
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getClassColor = (classificação: string) => {
    switch (classificação) {
      case 'Elite': return 'bg-tier-elite text-tier-elite-foreground';
      case 'Forte': return 'bg-tier-forte text-tier-forte-foreground';
      case 'Estável': return 'bg-tier-estavel text-tier-estavel-foreground';
      case 'Em desenvolvimento': return 'bg-tier-desenvolvimento text-tier-desenvolvimento-foreground';
      case 'Atenção': return 'bg-tier-atencao text-tier-atencao-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            <CardTitle>Análise de IA</CardTitle>
          </div>
          <Button 
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="flex items-center gap-2"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Analisando...
              </>
            ) : (
              <>
                <Brain className="h-4 w-4" />
                Gerar Análise
              </>
            )}
          </Button>
        </div>
        <CardDescription>
          {scouterId 
            ? `Análise inteligente do desempenho do scouter ${scouterName}`
            : `Análise inteligente do projeto ${projectName}`
          }
        </CardDescription>
      </CardHeader>

      {analysis && (
        <CardContent className="space-y-6">
          {/* Score e Classificação */}
          <div className="flex items-center justify-between p-4 bg-gradient-subtle rounded-lg">
            <div>
              <h3 className="font-semibold text-lg">Score Geral</h3>
              <p className="text-3xl font-bold text-primary">{analysis.score_geral}/100</p>
            </div>
            <Badge className={getClassColor(analysis.classificação)} variant="secondary">
              {analysis.classificação}
            </Badge>
          </div>

          {/* Panorama */}
          <div>
            <h4 className="font-semibold mb-2">Panorama Geral</h4>
            <p className="text-muted-foreground leading-relaxed">{analysis.panorama}</p>
          </div>

          <Separator />

          {/* Pontos Fortes */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <h4 className="font-semibold">Pontos Fortes</h4>
            </div>
            <ul className="space-y-2">
              {analysis.pontos_fortes.map((ponto, index) => (
                <li key={index} className="flex items-start gap-2">
                  <TrendingUp className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{ponto}</span>
                </li>
              ))}
            </ul>
          </div>

          <Separator />

          {/* Pontos de Atenção */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
              <h4 className="font-semibold">Pontos de Atenção</h4>
            </div>
            <ul className="space-y-2">
              {analysis.pontos_atenção.map((ponto, index) => (
                <li key={index} className="flex items-start gap-2">
                  <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{ponto}</span>
                </li>
              ))}
            </ul>
          </div>

          <Separator />

          {/* Recomendações */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Brain className="h-4 w-4 text-primary" />
              <h4 className="font-semibold">Recomendações</h4>
            </div>
            <ul className="space-y-2">
              {analysis.recomendações.map((rec, index) => (
                <li key={index} className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                  <span className="text-sm">{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      )}
    </Card>
  );
}