import React, { useState } from 'react';
import { Calendar, Filter, RefreshCw, Users, FolderOpen, Brain } from 'lucide-react';
import { AIAnalysis } from './AIAnalysis';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';
import type { AnalyticsFilters } from '@/types/scouter';
import type { DateRange } from 'react-day-picker';

interface FilterHeaderProps {
  filters: AnalyticsFilters;
  onFiltersChange: (filters: AnalyticsFilters) => void;
  loading?: boolean;
  showProjectFilter?: boolean;
  showScouterFilter?: boolean;
  showAIAnalysis?: boolean;
}

const presetRanges = [
  { label: 'Hoje', getValue: () => ({ start: new Date(), end: new Date() }) },
  { 
    label: 'Últimos 7 dias', 
    getValue: () => {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 6);
      return { start, end };
    }
  },
  { 
    label: 'Últimos 30 dias', 
    getValue: () => {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 29);
      return { start, end };
    }
  },
  { 
    label: 'Mês atual', 
    getValue: () => ({
      start: startOfMonth(new Date()),
      end: endOfMonth(new Date())
    })
  },
  { 
    label: 'Semana atual', 
    getValue: () => ({
      start: startOfWeek(new Date(), { weekStartsOn: 1 }),
      end: endOfWeek(new Date(), { weekStartsOn: 1 })
    })
  }
];

// Mock data - these would come from API
const mockScouters = [
  { id: '1', name: 'João Silva' },
  { id: '2', name: 'Maria Santos' },
  { id: '3', name: 'Pedro Costa' },
  { id: '4', name: 'Ana Lima' },
];

const mockProjects = [
  { id: '1', name: 'Projeto Alpha' },
  { id: '2', name: 'Projeto Beta' },
  { id: '3', name: 'Projeto Gamma' },
];

export function FilterHeader({ 
  filters, 
  onFiltersChange, 
  loading = false,
  showProjectFilter = true,
  showScouterFilter = true,
  showAIAnalysis = false
}: FilterHeaderProps) {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: filters.startDate ? new Date(filters.startDate) : undefined,
    to: filters.endDate ? new Date(filters.endDate) : undefined,
  });
  const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);

  const handleDateRangeSelect = (range: DateRange | undefined) => {
    setDateRange(range);
    onFiltersChange({
      ...filters,
      startDate: range?.from ? range.from.toISOString().split('T')[0] : undefined,
      endDate: range?.to ? range.to.toISOString().split('T')[0] : undefined,
    });
  };

  const handlePresetSelect = (preset: typeof presetRanges[0]) => {
    const { start, end } = preset.getValue();
    handleDateRangeSelect({ from: start, to: end });
    setIsDatePickerOpen(false);
  };

  const handleScouterToggle = (scouterId: string) => {
    const currentScouters = filters.scouterIds || [];
    const newScouters = currentScouters.includes(scouterId)
      ? currentScouters.filter(id => id !== scouterId)
      : [...currentScouters, scouterId];
    
    onFiltersChange({
      ...filters,
      scouterIds: newScouters.length > 0 ? newScouters : undefined,
    });
  };

  const handleProjectToggle = (projectId: string) => {
    const currentProjects = filters.projectIds || [];
    const newProjects = currentProjects.includes(projectId)
      ? currentProjects.filter(id => id !== projectId)
      : [...currentProjects, projectId];
    
    onFiltersChange({
      ...filters,
      projectIds: newProjects.length > 0 ? newProjects : undefined,
    });
  };

  const selectedScoutersCount = filters.scouterIds?.length || 0;
  const selectedProjectsCount = filters.projectIds?.length || 0;

  const selectedScouterName = filters.scouterIds?.[0] 
    ? mockScouters.find(s => s.id === filters.scouterIds?.[0])?.name
    : undefined;

  const selectedProjectName = filters.projectIds?.[0]
    ? mockProjects.find(p => p.id === filters.projectIds?.[0])?.name  
    : undefined;

  return (
    <div className="space-y-4">{showAIAnalysis && (selectedScouterName || selectedProjectName) && (
        <AIAnalysis 
          scouterId={filters.scouterIds?.[0]}
          scouterName={selectedScouterName}
          projectId={filters.projectIds?.[0]}
          projectName={selectedProjectName}
          filters={filters}
        />
      )}
    <Card className="glass p-6 mb-6">
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center flex-1">
          {/* Date Range Picker */}
          <div className="flex flex-col gap-2">
            <Label className="text-sm font-medium text-muted-foreground">
              Período
            </Label>
            <Popover open={isDatePickerOpen} onOpenChange={setIsDatePickerOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-[280px] justify-start text-left font-normal"
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange?.to ? (
                      <>
                        {format(dateRange.from, "dd/MM/yyyy", { locale: ptBR })} -{" "}
                        {format(dateRange.to, "dd/MM/yyyy", { locale: ptBR })}
                      </>
                    ) : (
                      format(dateRange.from, "dd/MM/yyyy", { locale: ptBR })
                    )
                  ) : (
                    <span>Selecione o período</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <div className="p-3 border-b">
                  <div className="text-sm font-medium mb-2">Períodos rápidos</div>
                  <div className="flex flex-wrap gap-2">
                    {presetRanges.map((preset) => (
                      <Button
                        key={preset.label}
                        variant="outline"
                        size="sm"
                        onClick={() => handlePresetSelect(preset)}
                      >
                        {preset.label}
                      </Button>
                    ))}
                  </div>
                </div>
                <CalendarComponent
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange?.from}
                  selected={dateRange}
                  onSelect={handleDateRangeSelect}
                  numberOfMonths={2}
                  locale={ptBR}
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Scouter Filter */}
          {showScouterFilter && (
            <div className="flex flex-col gap-2">
              <Label className="text-sm font-medium text-muted-foreground">
                Scouters
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-[200px] justify-start"
                  >
                    <Users className="mr-2 h-4 w-4" />
                    {selectedScoutersCount === 0 
                      ? 'Todos os scouters'
                      : `${selectedScoutersCount} selecionado${selectedScoutersCount > 1 ? 's' : ''}`
                    }
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[300px] p-3">
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Selecionar Scouters</div>
                    <div className="max-h-[200px] overflow-y-auto space-y-2">
                      {mockScouters.map((scouter) => (
                        <div
                          key={scouter.id}
                          className="flex items-center justify-between p-2 rounded hover:bg-muted cursor-pointer"
                          onClick={() => handleScouterToggle(scouter.id)}
                        >
                          <span className="text-sm">{scouter.name}</span>
                          {filters.scouterIds?.includes(scouter.id) && (
                            <Badge variant="secondary" className="text-xs">
                              ✓
                            </Badge>
                          )}
                        </div>
                      ))}
                    </div>
                    {selectedScoutersCount > 0 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onFiltersChange({ ...filters, scouterIds: undefined })}
                        className="w-full"
                      >
                        Limpar seleção
                      </Button>
                    )}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          )}

          {/* Project Filter */}
          {showProjectFilter && (
            <div className="flex flex-col gap-2">
              <Label className="text-sm font-medium text-muted-foreground">
                Projetos
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-[200px] justify-start"
                  >
                    <FolderOpen className="mr-2 h-4 w-4" />
                    {selectedProjectsCount === 0 
                      ? 'Todos os projetos'
                      : `${selectedProjectsCount} selecionado${selectedProjectsCount > 1 ? 's' : ''}`
                    }
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[300px] p-3">
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Selecionar Projetos</div>
                    <div className="max-h-[200px] overflow-y-auto space-y-2">
                      {mockProjects.map((project) => (
                        <div
                          key={project.id}
                          className="flex items-center justify-between p-2 rounded hover:bg-muted cursor-pointer"
                          onClick={() => handleProjectToggle(project.id)}
                        >
                          <span className="text-sm">{project.name}</span>
                          {filters.projectIds?.includes(project.id) && (
                            <Badge variant="secondary" className="text-xs">
                              ✓
                            </Badge>
                          )}
                        </div>
                      ))}
                    </div>
                    {selectedProjectsCount > 0 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onFiltersChange({ ...filters, projectIds: undefined })}
                        className="w-full"
                      >
                        Limpar seleção
                      </Button>
                    )}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.location.reload()}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onFiltersChange({})}
          >
            <Filter className="h-4 w-4 mr-2" />
            Limpar Filtros
          </Button>
        </div>
      </div>

        {/* Active Filters Display */}
        {(selectedScoutersCount > 0 || selectedProjectsCount > 0 || dateRange?.from) && (
          <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t">
            {dateRange?.from && (
              <Badge variant="secondary" className="gap-2">
                Período: {format(dateRange.from, "dd/MM", { locale: ptBR })}
                {dateRange.to && ` - ${format(dateRange.to, "dd/MM", { locale: ptBR })}`}
              </Badge>
            )}
          {selectedScoutersCount > 0 && (
            <Badge variant="secondary">
              {selectedScoutersCount} scouter{selectedScoutersCount > 1 ? 's' : ''}
            </Badge>
          )}
          {selectedProjectsCount > 0 && (
            <Badge variant="secondary">
              {selectedProjectsCount} projeto{selectedProjectsCount > 1 ? 's' : ''}
            </Badge>
          )}
        </div>
      )}
    </Card>
    </div>
  );
}