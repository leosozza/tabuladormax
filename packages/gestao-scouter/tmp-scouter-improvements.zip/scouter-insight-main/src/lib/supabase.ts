import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Utility functions for common operations
export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function signInWithEmail(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  if (error) throw error;
  return data;
}

export async function signUpWithEmail(email: string, password: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });
  if (error) throw error;
  return data;
}

// RPC functions for analytics
export async function getAnalyticsKPIs(filters: {
  start_date?: string;
  end_date?: string;
  scouter_ids?: string[];
  project_ids?: string[];
}) {
  const { data, error } = await supabase.rpc('analytics_kpis', filters);
  if (error) throw error;
  return data;
}

export async function getScouterRanking(filters: {
  start_date?: string;
  end_date?: string;
  project_ids?: string[];
}) {
  const { data, error } = await supabase.rpc('get_scouter_ranking', filters);
  if (error) throw error;
  return data;
}

export async function getScouterProjections(month?: string) {
  const { data, error } = await supabase.rpc('get_scouter_projections', { 
    target_month: month 
  });
  if (error) throw error;
  return data;
}

export async function generatePaymentBatch(params: {
  period_start: string;
  period_end: string;
  project_id?: string;
  scouter_ids?: string[];
}) {
  const { data, error } = await supabase.rpc('payments_generate', params);
  if (error) throw error;
  return data;
}

export async function commitPaymentBatch(payment_id: string) {
  const { data, error } = await supabase.rpc('payments_commit', { payment_id });
  if (error) throw error;
  return data;
}

export async function markPaymentAsPaid(payment_id: string, metadata?: any) {
  const { data, error } = await supabase.rpc('payments_mark_paid', {
    payment_id,
    payment_metadata: metadata
  });
  if (error) throw error;
  return data;
}

export async function getHeatmapData(filters: {
  start_date?: string;
  end_date?: string;
  project_ids?: string[];
  h3_res?: number;
}) {
  const { data, error } = await supabase.rpc('geo_heatmap', filters);
  if (error) throw error;
  return data;
}

export async function searchLeads(filters: {
  start_date?: string;
  end_date?: string;
  scouter_ids?: string[];
  project_ids?: string[];
  stage?: string;
  page?: number;
  limit?: number;
}) {
  const { data, error } = await supabase.rpc('leads_search', filters);
  if (error) throw error;
  return data;
}

// Schema ensure function
export async function ensureSchema() {
  const { data, error } = await supabase.rpc('schema_ensure');
  if (error) throw error;
  return data;
}