import React, { useState } from 'react';
import { Settings, Database, Webhook, FileText, Users, Sliders, Shield, TestTube, Zap, Save, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/hooks/use-toast';

// Mock configuration data
const mockBitrixConfig = {
  base_url: 'https://empresa.bitrix24.com',
  auth_mode: 'webhook' as const,
  webhook_user_id: '1',
  webhook_token: 'abc123***',
  connection_status: 'connected' as const,
  last_sync: '2024-01-15T14:30:00Z'
};

const mockIndicatorWeights = {
  peso_foto: 20,
  peso_confirmada: 20,
  peso_contato: 10,
  peso_interesse: 10,
  peso_agendado: 15,
  peso_compareceu: 20,
  peso_concluido_pos: 25,
  peso_concluido_neg: -10,
  peso_sem_interesse_def: -20,
  peso_sem_contato: -15,
  peso_sem_interesse_momento: -5
};

const mockPaymentMultipliers = {
  'novo': 0.00,
  'confirmado': 0.00,
  'interesse': 0.50,
  'agendado': 0.75,
  'compareceu': 0.90,
  'concluido_pos': 1.00,
  'concluido_neg': 0.25,
  'sem_interesse_def': 0.00,
  'sem_contato': 0.00,
  'sem_interesse_momento': 0.00
};

const mockEligibilityRules = {
  exigir_foto: true,
  exigir_confirmacao: true,
  exigir_contato: false
};

const mockScouterClassifications = [
  {
    id: '1',
    scouter_name: 'João Silva',
    tier: 'Senior',
    valor_por_ficha: 7.00,
    ajuda_custo: 50.00,
    meta_fichas: 850,
    pct_min_interesse: 15.0,
    pct_max_sem_contato: 25.0,
    pct_min_fotos: 85.0,
    pct_min_agendadas: 40.0,
    pct_min_compareceu: 15.0
  },
  {
    id: '2',
    scouter_name: 'Maria Santos',
    tier: 'Premium',
    valor_por_ficha: 6.00,
    ajuda_custo: 45.00,
    meta_fichas: 650,
    pct_min_interesse: 12.0,
    pct_max_sem_contato: 30.0,
    pct_min_fotos: 80.0,
    pct_min_agendadas: 35.0,
    pct_min_compareceu: 12.0
  }
];

export default function Configuration() {
  const [loading, setLoading] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);
  const [weights, setWeights] = useState(mockIndicatorWeights);
  const [multipliers, setMultipliers] = useState(mockPaymentMultipliers);
  const [eligibilityRules, setEligibilityRules] = useState(mockEligibilityRules);
  const { toast } = useToast();

  const handleSaveConfiguration = async () => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Configurações salvas",
        description: "As configurações foram atualizadas com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar as configurações.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTestConnection = async () => {
    setTestingConnection(true);
    try {
      // Simulate connection test
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Conexão testada com sucesso",
        description: "A conexão com o Bitrix24 está funcionando corretamente.",
      });
    } catch (error) {
      toast({
        title: "Erro na conexão",
        description: "Não foi possível conectar com o Bitrix24.",
        variant: "destructive"
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const handleWeightChange = (key: string, value: number[]) => {
    setWeights(prev => ({ ...prev, [key]: value[0] }));
  };

  const handleMultiplierChange = (stage: string, value: string) => {
    setMultipliers(prev => ({ ...prev, [stage]: parseFloat(value) }));
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
        <p className="text-muted-foreground">
          Configure integrações, parâmetros de análise e regras de pagamento
        </p>
      </div>

      <Tabs defaultValue="bitrix" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="bitrix">Bitrix24</TabsTrigger>
          <TabsTrigger value="weights">Pesos</TabsTrigger>
          <TabsTrigger value="payments">Pagamentos</TabsTrigger>
          <TabsTrigger value="scouters">Scouters</TabsTrigger>
          <TabsTrigger value="system">Sistema</TabsTrigger>
        </TabsList>

        {/* Bitrix Configuration */}
        <TabsContent value="bitrix" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Integração Bitrix24
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-success rounded-full"></div>
                  <div>
                    <div className="font-medium">Conexão Ativa</div>
                    <div className="text-sm text-muted-foreground">
                      Última sincronização: 15/01/2024 às 14:30
                    </div>
                  </div>
                </div>
                <Badge variant="secondary">Conectado</Badge>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="bitrix-url">URL do Bitrix24</Label>
                  <Input
                    id="bitrix-url"
                    value={mockBitrixConfig.base_url}
                    placeholder="https://empresa.bitrix24.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="auth-mode">Modo de Autenticação</Label>
                  <Select value={mockBitrixConfig.auth_mode}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="webhook">Webhook</SelectItem>
                      <SelectItem value="oauth">OAuth</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="webhook-user">ID do Usuário Webhook</Label>
                  <Input
                    id="webhook-user"
                    value={mockBitrixConfig.webhook_user_id}
                    placeholder="1"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="webhook-token">Token do Webhook</Label>
                  <Input
                    id="webhook-token"
                    type="password"
                    value={mockBitrixConfig.webhook_token}
                    placeholder="Token aqui..."
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleTestConnection}
                  disabled={testingConnection}
                >
                  {testingConnection ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <TestTube className="h-4 w-4 mr-2" />
                  )}
                  Testar Conexão
                </Button>
                <Button>
                  <Zap className="h-4 w-4 mr-2" />
                  Sincronizar Agora
                </Button>
              </div>

              <Alert>
                <Webhook className="h-4 w-4" />
                <AlertDescription>
                  A sincronização automática ocorre diariamente às 02:00. Você pode executar sincronizações manuais quando necessário.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Indicator Weights */}
        <TabsContent value="weights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sliders className="h-5 w-5" />
                Pesos dos Indicadores
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <Sliders className="h-4 w-4" />
                <AlertDescription>
                  Os pesos influenciam o cálculo do IQS (Índice de Qualidade). Valores negativos reduzem a pontuação.
                </AlertDescription>
              </Alert>

              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-4">
                  <h3 className="font-semibold text-success">Indicadores Positivos</h3>
                  
                  {Object.entries(weights)
                    .filter(([_, value]) => value >= 0)
                    .map(([key, value]) => {
                      const labels: Record<string, string> = {
                        peso_foto: 'Foto',
                        peso_confirmada: 'Ficha Confirmada',
                        peso_contato: 'Conseguiu Contato',
                        peso_interesse: 'Com Interesse',
                        peso_agendado: 'Agendado',
                        peso_compareceu: 'Compareceu',
                        peso_concluido_pos: 'Concluído Positivo'
                      };
                      
                      return (
                        <div key={key} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label className="text-sm">{labels[key]}</Label>
                            <span className="text-sm font-medium text-success">{value}</span>
                          </div>
                          <Slider
                            value={[value]}
                            onValueChange={(val) => handleWeightChange(key, val)}
                            max={50}
                            min={0}
                            step={1}
                            className="w-full"
                          />
                        </div>
                      );
                    })}
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold text-destructive">Indicadores Negativos</h3>
                  
                  {Object.entries(weights)
                    .filter(([_, value]) => value < 0)
                    .map(([key, value]) => {
                      const labels: Record<string, string> = {
                        peso_concluido_neg: 'Concluído Negativo',
                        peso_sem_interesse_def: 'Sem Interesse Definitivo',
                        peso_sem_contato: 'Sem Contato',
                        peso_sem_interesse_momento: 'Sem Interesse no Momento'
                      };
                      
                      return (
                        <div key={key} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label className="text-sm">{labels[key]}</Label>
                            <span className="text-sm font-medium text-destructive">{value}</span>
                          </div>
                          <Slider
                            value={[Math.abs(value)]}
                            onValueChange={(val) => handleWeightChange(key, [-val[0]])}
                            max={30}
                            min={0}
                            step={1}
                            className="w-full"
                          />
                        </div>
                      );
                    })}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Configuration */}
        <TabsContent value="payments" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Multiplicadores por Etapa
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(multipliers).map(([stage, value]) => {
                  const stageLabels: Record<string, string> = {
                    'novo': 'Novo',
                    'confirmado': 'Confirmado',
                    'interesse': 'Interesse',
                    'agendado': 'Agendado',
                    'compareceu': 'Compareceu',
                    'concluido_pos': 'Concluído Positivo',
                    'concluido_neg': 'Concluído Negativo',
                    'sem_interesse_def': 'Sem Interesse Definitivo',
                    'sem_contato': 'Sem Contato',
                    'sem_interesse_momento': 'Sem Interesse no Momento'
                  };

                  return (
                    <div key={stage} className="flex items-center justify-between">
                      <Label className="text-sm">{stageLabels[stage]}</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          step="0.01"
                          min="0"
                          max="2"
                          value={value}
                          onChange={(e) => handleMultiplierChange(stage, e.target.value)}
                          className="w-20 text-right"
                        />
                        <span className="text-xs">×</span>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Regras de Elegibilidade
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Exigir Foto</Label>
                    <p className="text-xs text-muted-foreground">
                      Ficha deve ter foto para ser paga
                    </p>
                  </div>
                  <Switch
                    checked={eligibilityRules.exigir_foto}
                    onCheckedChange={(checked) => 
                      setEligibilityRules(prev => ({ ...prev, exigir_foto: checked }))
                    }
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Exigir Confirmação WhatsApp</Label>
                    <p className="text-xs text-muted-foreground">
                      WhatsApp deve estar confirmado
                    </p>
                  </div>
                  <Switch
                    checked={eligibilityRules.exigir_confirmacao}
                    onCheckedChange={(checked) => 
                      setEligibilityRules(prev => ({ ...prev, exigir_confirmacao: checked }))
                    }
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Exigir Contato Concluído</Label>
                    <p className="text-xs text-muted-foreground">
                      Contato deve estar marcado como feito
                    </p>
                  </div>
                  <Switch
                    checked={eligibilityRules.exigir_contato}
                    onCheckedChange={(checked) => 
                      setEligibilityRules(prev => ({ ...prev, exigir_contato: checked }))
                    }
                  />
                </div>

                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    Fichas que não atendem aos critérios não serão incluídas nos pagamentos.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Scouter Classifications */}
        <TabsContent value="scouters" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Classificação dos Scouters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Scouter</th>
                      <th className="text-left p-2">Tier</th>
                      <th className="text-right p-2">Valor/Ficha</th>
                      <th className="text-right p-2">Ajuda Custo</th>
                      <th className="text-right p-2">Meta</th>
                      <th className="text-right p-2">Min. Interesse</th>
                      <th className="text-right p-2">Max. S/ Contato</th>
                      <th className="text-center p-2">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockScouterClassifications.map((scouter) => (
                      <tr key={scouter.id} className="border-b hover:bg-muted/30">
                        <td className="p-2 font-medium">{scouter.scouter_name}</td>
                        <td className="p-2">
                          <Badge variant="outline">{scouter.tier}</Badge>
                        </td>
                        <td className="p-2 text-right">
                          R$ {scouter.valor_por_ficha.toFixed(2)}
                        </td>
                        <td className="p-2 text-right">
                          R$ {scouter.ajuda_custo.toFixed(2)}
                        </td>
                        <td className="p-2 text-right">
                          {scouter.meta_fichas.toLocaleString('pt-BR')}
                        </td>
                        <td className="p-2 text-right">
                          {scouter.pct_min_interesse.toFixed(1)}%
                        </td>
                        <td className="p-2 text-right">
                          {scouter.pct_max_sem_contato.toFixed(1)}%
                        </td>
                        <td className="p-2 text-center">
                          <Button variant="outline" size="sm">
                            Editar
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Configuration */}
        <TabsContent value="system" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Configurações do Sistema
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="sync-interval">Intervalo de Sincronização (horas)</Label>
                  <Select defaultValue="24">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 hora</SelectItem>
                      <SelectItem value="6">6 horas</SelectItem>
                      <SelectItem value="12">12 horas</SelectItem>
                      <SelectItem value="24">24 horas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="geo-precision">Precisão Geográfica</Label>
                  <Select defaultValue="3">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">Baixa (2 casas)</SelectItem>
                      <SelectItem value="3">Média (3 casas)</SelectItem>
                      <SelectItem value="4">Alta (4 casas)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Notificações de Sync</Label>
                    <p className="text-xs text-muted-foreground">
                      Receber notificações sobre sincronizações
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Logs Detalhados</Label>
                    <p className="text-xs text-muted-foreground">
                      Manter logs detalhados das operações
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Backup Automático</Label>
                    <p className="text-xs text-muted-foreground">
                      Fazer backup diário dos dados
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Button */}
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold">Salvar Configurações</h3>
            <p className="text-sm text-muted-foreground">
              Aplique todas as alterações feitas nas configurações
            </p>
          </div>
          <Button 
            onClick={handleSaveConfiguration}
            disabled={loading}
            size="lg"
            className="btn-dashboard"
          >
            {loading ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Salvar Alterações
          </Button>
        </div>
      </Card>
    </div>
  );
}