import React, { useState } from 'react';
import { Target, Upload, FileSpreadsheet, TrendingUp, Calendar, Users, BarChart3, Download } from 'lucide-react';
import { FilterHeader } from '@/components/shared/FilterHeader';
import { KPICard } from '@/components/ui/kpi-card';
import { DataTable } from '@/components/shared/DataTable';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import type { AnalyticsFilters, ScouterProjection } from '@/types/scouter';

// Mock data baseado na planilha analisada
const mockScouterGoals = [
  {
    scouter_name: 'João Silva',
    tier: 'Senior',
    meta_fichas: 850,
    fichas_atual: 450,
    progress: 52.9,
    proj_fim_mes: 680,
    gap_meta: -170,
    valor_ficha: 7.00,
    ajuda_custo: 50.00,
    comparecimento_meta: 51,
    comparecimento_atual: 28,
    fechado_meta: 26,
    fechado_atual: 12,
    dias_trabalhados: 22,
    media_diaria: 20.5
  },
  {
    scouter_name: 'Maria Santos',
    tier: 'Premium',
    meta_fichas: 650,
    fichas_atual: 420,
    progress: 64.6,
    proj_fim_mes: 595,
    gap_meta: -55,
    valor_ficha: 6.00,
    ajuda_custo: 45.00,
    comparecimento_meta: 39,
    comparecimento_atual: 22,
    fechado_meta: 20,
    fechado_atual: 11,
    dias_trabalhados: 22,
    media_diaria: 19.1
  },
  {
    scouter_name: 'Pedro Costa',
    tier: 'Pleno',
    meta_fichas: 500,
    fichas_atual: 380,
    progress: 76.0,
    proj_fim_mes: 520,
    gap_meta: 20,
    valor_ficha: 5.00,
    ajuda_custo: 40.00,
    comparecimento_meta: 24,
    comparecimento_atual: 18,
    fechado_meta: 12,
    fechado_atual: 9,
    dias_trabalhados: 22,
    media_diaria: 17.3
  },
  {
    scouter_name: 'Ana Lima',
    tier: 'Aprendiz',
    meta_fichas: 500,
    fichas_atual: 290,
    progress: 58.0,
    proj_fim_mes: 465,
    gap_meta: -35,
    valor_ficha: 4.00,
    ajuda_custo: 30.00,
    comparecimento_meta: 18,
    comparecimento_atual: 12,
    fechado_meta: 9,
    fechado_atual: 6,
    dias_trabalhados: 22,
    media_diaria: 13.2
  }
];

const tierColors = {
  'Senior': 'badge-tier-elite',
  'Premium': 'badge-tier-forte',
  'Pleno': 'badge-tier-estavel',
  'Aprendiz': 'badge-tier-desenvolvimento'
};

export default function Goals() {
  const [filters, setFilters] = useState<AnalyticsFilters>({});
  const [loading, setLoading] = useState(false);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { toast } = useToast();

  const handleFileUpload = async () => {
    if (!selectedFile) return;

    setUploadLoading(true);
    try {
      // Simulate file processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Metas importadas com sucesso",
        description: `${mockScouterGoals.length} scouters processados da planilha.`,
      });
      
      setSelectedFile(null);
    } catch (error) {
      toast({
        title: "Erro na importação",
        description: "Ocorreu um erro ao processar a planilha.",
        variant: "destructive",
      });
    } finally {
      setUploadLoading(false);
    }
  };

  const goalsColumns = [
    {
      key: 'scouter_name' as keyof typeof mockScouterGoals[0],
      title: 'Scouter',
      sortable: true,
      render: (value: string, row: typeof mockScouterGoals[0]) => (
        <div className="flex flex-col">
          <span className="font-medium">{value}</span>
          <Badge className={tierColors[row.tier as keyof typeof tierColors]}>
            {row.tier}
          </Badge>
        </div>
      )
    },
    {
      key: 'meta_fichas' as keyof typeof mockScouterGoals[0],
      title: 'Meta Fichas',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => value.toLocaleString('pt-BR')
    },
    {
      key: 'fichas_atual' as keyof typeof mockScouterGoals[0],
      title: 'Atual',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => value.toLocaleString('pt-BR')
    },
    {
      key: 'progress' as keyof typeof mockScouterGoals[0],
      title: 'Progresso',
      render: (value: number, row: typeof mockScouterGoals[0]) => (
        <div className="flex items-center gap-2 min-w-[120px]">
          <Progress 
            value={value} 
            className={`flex-1 h-2 ${value >= 100 ? 'progress-success' : value >= 80 ? 'progress-warning' : ''}`}
          />
          <span className="text-xs font-medium min-w-[40px]">
            {value.toFixed(0)}%
          </span>
        </div>
      )
    },
    {
      key: 'proj_fim_mes' as keyof typeof mockScouterGoals[0],
      title: 'Projeção',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => value.toLocaleString('pt-BR')
    },
    {
      key: 'gap_meta' as keyof typeof mockScouterGoals[0],
      title: 'Gap',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => (
        <span className={value >= 0 ? 'text-success font-medium' : 'text-destructive font-medium'}>
          {value >= 0 ? '+' : ''}{value}
        </span>
      )
    },
    {
      key: 'comparecimento_atual' as keyof typeof mockScouterGoals[0],
      title: 'Comparecimento',
      render: (value: number, row: typeof mockScouterGoals[0]) => (
        <div className="text-center">
          <div className="text-sm font-medium">{value}/{row.comparecimento_meta}</div>
          <div className="text-xs text-muted-foreground">
            {((value / row.comparecimento_meta) * 100).toFixed(0)}%
          </div>
        </div>
      )
    },
    {
      key: 'fechado_atual' as keyof typeof mockScouterGoals[0],
      title: 'Fechados',
      render: (value: number, row: typeof mockScouterGoals[0]) => (
        <div className="text-center">
          <div className="text-sm font-medium">{value}/{row.fechado_meta}</div>
          <div className="text-xs text-muted-foreground">
            {((value / row.fechado_meta) * 100).toFixed(0)}%
          </div>
        </div>
      )
    },
    {
      key: 'media_diaria' as keyof typeof mockScouterGoals[0],
      title: 'Média Diária',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => `${value.toFixed(1)}`
    }
  ];

  const summaryStats = {
    total_scouters: mockScouterGoals.length,
    meta_total: mockScouterGoals.reduce((sum, s) => sum + s.meta_fichas, 0),
    atual_total: mockScouterGoals.reduce((sum, s) => sum + s.fichas_atual, 0),
    proj_total: mockScouterGoals.reduce((sum, s) => sum + s.proj_fim_mes, 0),
    scouters_acima_meta: mockScouterGoals.filter(s => s.gap_meta >= 0).length
  };

  const progressGeral = (summaryStats.atual_total / summaryStats.meta_total) * 100;

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Metas & Projeções</h1>
        <p className="text-muted-foreground">
          Gerencie metas dos scouters e acompanhe projeções de performance
        </p>
      </div>

      {/* Import Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Importar Metas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-end">
            <div className="flex-1 space-y-2">
              <Label htmlFor="file-upload">
                Selecione a planilha de metas (XLSX)
              </Label>
              <Input
                id="file-upload"
                type="file"
                accept=".xlsx,.xls"
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
              />
              <p className="text-xs text-muted-foreground">
                Formato suportado: Excel (.xlsx, .xls) com colunas de Nome, Meta Semanal, Meta Mensal
              </p>
            </div>
            
            <Button 
              onClick={handleFileUpload}
              disabled={!selectedFile || uploadLoading}
              className={uploadLoading ? 'animate-pulse' : ''}
            >
              {uploadLoading ? (
                <>
                  <Upload className="h-4 w-4 mr-2 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Importar Metas
                </>
              )}
            </Button>
          </div>

          {selectedFile && (
            <Alert className="mt-4">
              <FileSpreadsheet className="h-4 w-4" />
              <AlertDescription>
                Arquivo selecionado: <strong>{selectedFile.name}</strong> ({(selectedFile.size / 1024).toFixed(1)} KB)
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Summary KPIs */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KPICard
          title="Total Scouters"
          value={summaryStats.total_scouters}
          format="number"
          icon={<Users className="h-4 w-4" />}
        />
        <KPICard
          title="Meta Total"
          value={summaryStats.meta_total}
          format="number"
          icon={<Target className="h-4 w-4" />}
          variant="forte"
        />
        <KPICard
          title="Progresso Geral"
          value={progressGeral}
          format="percentage"
          icon={<TrendingUp className="h-4 w-4" />}
          variant={progressGeral >= 80 ? "elite" : progressGeral >= 60 ? "forte" : "warning"}
        />
        <KPICard
          title="Scouters Acima da Meta"
          value={summaryStats.scouters_acima_meta}
          format="number"
          subtitle={`de ${summaryStats.total_scouters} total`}
          icon={<BarChart3 className="h-4 w-4" />}
          variant="elite"
        />
      </div>

      {/* Filters */}
      <FilterHeader 
        filters={filters}
        onFiltersChange={setFilters}
        loading={loading}
        showProjectFilter={false}
      />

      {/* Goals Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Acompanhamento de Metas por Scouter
            </CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Exportar Relatório
              </Button>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Calendar className="h-4 w-4 mr-2" />
                    Alterar Período
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Configurar Período das Metas</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="start-date">Data de Início</Label>
                      <Input id="start-date" type="date" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="end-date">Data de Fim</Label>
                      <Input id="end-date" type="date" />
                    </div>
                    <Button className="w-full">
                      Aplicar Período
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Alert>
              <Target className="h-4 w-4" />
              <AlertDescription>
                <strong>Cálculo de Projeção:</strong> Baseado na média diária dos últimos 14 dias × dias úteis restantes × taxa de confirmação recente
              </AlertDescription>
            </Alert>

            <DataTable
              data={mockScouterGoals}
              columns={goalsColumns}
              loading={loading}
              exportFilename="metas-projecoes"
            />
          </div>
        </CardContent>
      </Card>

      {/* Tier Performance Analysis */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Performance por Tier</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(tierColors).map(([tier, colorClass]) => {
                const tierScouters = mockScouterGoals.filter(s => s.tier === tier);
                const avgProgress = tierScouters.reduce((sum, s) => sum + s.progress, 0) / tierScouters.length;
                
                return (
                  <div key={tier} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className={colorClass}>{tier}</Badge>
                      <span className="text-sm text-muted-foreground">
                        ({tierScouters.length} scouters)
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={avgProgress} className="w-20 h-2" />
                      <span className="text-sm font-medium w-12">
                        {avgProgress.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Distribuição de Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">Acima da Meta (100%+)</span>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-success rounded"></div>
                  <span className="text-sm font-medium">
                    {mockScouterGoals.filter(s => s.progress >= 100).length}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Próximo da Meta (80-99%)</span>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-warning rounded"></div>
                  <span className="text-sm font-medium">
                    {mockScouterGoals.filter(s => s.progress >= 80 && s.progress < 100).length}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Precisa Melhorar (60-79%)</span>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-orange-500 rounded"></div>
                  <span className="text-sm font-medium">
                    {mockScouterGoals.filter(s => s.progress >= 60 && s.progress < 80).length}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Atenção Necessária (&lt;60%)</span>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-destructive rounded"></div>
                  <span className="text-sm font-medium">
                    {mockScouterGoals.filter(s => s.progress < 60).length}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}