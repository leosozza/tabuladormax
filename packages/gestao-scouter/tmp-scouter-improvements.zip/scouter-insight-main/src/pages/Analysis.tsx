import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Users, Target, MapPin, Camera, MessageCircle, Phone, CheckCircle, Calendar, Eye, ThumbsUp, ThumbsDown, AlertTriangle, PhoneMissed, Clock } from 'lucide-react';
import { FilterHeader } from '@/components/shared/FilterHeader';
import { KPICard } from '@/components/ui/kpi-card';
import { DataTable } from '@/components/shared/DataTable';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import type { AnalyticsFilters, KPIData, ScouterMetrics, Lead } from '@/types/scouter';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// Mock data - these would come from API
const mockKPIs: KPIData = {
  total_fichas: 15420,
  pct_com_foto: 84.5,
  pct_confirmadas: 76.2,
  pct_contato: 68.7,
  pct_agendadas: 42.3,
  pct_compareceu: 18.9,
  pct_interesse: 12.4,
  pct_concluido_pos: 8.7,
  pct_concluido_neg: 15.6,
  pct_sem_interesse_def: 22.1,
  pct_sem_contato: 31.3,
  pct_sem_interesse_momento: 8.2,
  iqs_medio: 73.6
};

const mockScouterMetrics: ScouterMetrics[] = [
  {
    scouter_id: '1',
    scouter_name: 'João Silva',
    leads_total: 2450,
    fichas_sim: 1980,
    taxa_ficha: 80.8,
    presencas_sim: 485,
    taxa_presenca: 19.8,
    dias_ate_conf_media: 2.3,
    media_diaria_ult14d: 42.1,
    taxa_conf_14d: 78.5,
    elegivel: true,
    score_conversao: 0.92,
    score_velocidade: 0.88,
    score_volume: 0.95,
    score_presenca: 0.76,
    score_composto: 0.89,
    classe: 'Elite',
    tier_name: 'S3',
    ...mockKPIs
  },
  {
    scouter_id: '2',
    scouter_name: 'Maria Santos',
    leads_total: 1890,
    fichas_sim: 1420,
    taxa_ficha: 75.1,
    presencas_sim: 298,
    taxa_presenca: 15.8,
    dias_ate_conf_media: 3.1,
    media_diaria_ult14d: 35.2,
    taxa_conf_14d: 72.3,
    elegivel: true,
    score_conversao: 0.78,
    score_velocidade: 0.71,
    score_volume: 0.82,
    score_presenca: 0.65,
    score_composto: 0.75,
    classe: 'Forte',
    tier_name: 'S2',
    ...mockKPIs
  },
  {
    scouter_id: '3',
    scouter_name: 'Pedro Costa',
    leads_total: 1650,
    fichas_sim: 1155,
    taxa_ficha: 70.0,
    presencas_sim: 215,
    taxa_presenca: 13.0,
    dias_ate_conf_media: 4.2,
    media_diaria_ult14d: 28.7,
    taxa_conf_14d: 68.9,
    elegivel: true,
    score_conversao: 0.65,
    score_velocidade: 0.58,
    score_volume: 0.71,
    score_presenca: 0.52,
    score_composto: 0.62,
    classe: 'Estável',
    tier_name: 'S2',
    ...mockKPIs
  }
];

const mockLeads: Lead[] = [
  {
    id: '1',
    created_at: '2024-01-15T10:30:00Z',
    modelo: 'Ana Silva',
    idade: 28,
    has_photo: true,
    confirmed_whatsapp: true,
    contacted: true,
    stage: 'compareceu',
    iqs: 87.5,
    responsavel: 'João Silva',
    observacoes: 'Cliente muito interessada'
  },
  {
    id: '2', 
    created_at: '2024-01-15T14:22:00Z',
    modelo: 'Carlos Santos',
    idade: 35,
    has_photo: true,
    confirmed_whatsapp: false,
    contacted: true,
    stage: 'agendado',
    iqs: 72.3,
    responsavel: 'Maria Santos',
    observacoes: 'Reagendado para próxima semana'
  }
];

export default function Analysis() {
  const [filters, setFilters] = useState<AnalyticsFilters>({});
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Simulated data fetching
  useEffect(() => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, [filters]);

  const getClassBadgeVariant = (classe: string) => {
    switch (classe) {
      case 'Elite': return 'badge-tier-elite';
      case 'Forte': return 'badge-tier-forte';
      case 'Estável': return 'badge-tier-estavel';
      case 'Em desenvolvimento': return 'badge-tier-desenvolvimento';
      case 'Atenção': return 'badge-tier-atencao';
      default: return 'secondary';
    }
  };

  const scouterColumns = [
    {
      key: 'scouter_name' as keyof ScouterMetrics,
      title: 'Scouter',
      sortable: true,
      render: (value: string, row: ScouterMetrics) => (
        <div className="flex flex-col">
          <span className="font-medium">{value}</span>
          {row.tier_name && (
            <Badge variant="outline" className="w-fit text-xs">
              {row.tier_name}
            </Badge>
          )}
        </div>
      )
    },
    {
      key: 'classe' as keyof ScouterMetrics,
      title: 'Classe',
      render: (value: string) => (
        <Badge className={getClassBadgeVariant(value)}>
          {value}
        </Badge>
      )
    },
    {
      key: 'leads_total' as keyof ScouterMetrics,
      title: 'Total Fichas',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => value.toLocaleString('pt-BR')
    },
    {
      key: 'taxa_ficha' as keyof ScouterMetrics,
      title: 'Taxa Confirmação',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => `${value.toFixed(1)}%`
    },
    {
      key: 'taxa_presenca' as keyof ScouterMetrics,
      title: 'Taxa Presença',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => `${value.toFixed(1)}%`
    },
    {
      key: 'dias_ate_conf_media' as keyof ScouterMetrics,
      title: 'Dias até Conf.',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => `${value.toFixed(1)}d`
    },
    {
      key: 'score_composto' as keyof ScouterMetrics,
      title: 'Score',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => (
        <div className="flex items-center gap-2">
          <Progress value={value * 100} className="w-16 h-2" />
          <span className="text-sm font-medium">{(value * 100).toFixed(0)}</span>
        </div>
      )
    }
  ];

  const leadColumns = [
    {
      key: 'created_at' as keyof Lead,
      title: 'Data',
      sortable: true,
      render: (value: string) => format(new Date(value), 'dd/MM/yyyy HH:mm', { locale: ptBR })
    },
    {
      key: 'modelo' as keyof Lead,
      title: 'Modelo',
      sortable: true
    },
    {
      key: 'idade' as keyof Lead,
      title: 'Idade',
      sortable: true,
      align: 'center' as const
    },
    {
      key: 'responsavel' as keyof Lead,
      title: 'Scouter',
      sortable: true
    },
    {
      key: 'has_photo' as keyof Lead,
      title: 'Foto',
      align: 'center' as const,
      render: (value: boolean) => value ? 
        <Camera className="h-4 w-4 text-success mx-auto" /> : 
        <Camera className="h-4 w-4 text-muted-foreground mx-auto" />
    },
    {
      key: 'confirmed_whatsapp' as keyof Lead,
      title: 'WhatsApp',
      align: 'center' as const,
      render: (value: boolean) => value ? 
        <MessageCircle className="h-4 w-4 text-success mx-auto" /> : 
        <MessageCircle className="h-4 w-4 text-muted-foreground mx-auto" />
    },
    {
      key: 'contacted' as keyof Lead,
      title: 'Contato',
      align: 'center' as const,
      render: (value: boolean) => value ? 
        <Phone className="h-4 w-4 text-success mx-auto" /> : 
        <Phone className="h-4 w-4 text-muted-foreground mx-auto" />
    },
    {
      key: 'stage' as keyof Lead,
      title: 'Etapa',
      render: (value: string) => {
        const stageConfig = {
          'novo': { label: 'Novo', color: 'secondary' },
          'confirmado': { label: 'Confirmado', color: 'secondary' },
          'interesse': { label: 'Interesse', color: 'warning' },
          'agendado': { label: 'Agendado', color: 'info' },
          'compareceu': { label: 'Compareceu', color: 'success' },
          'concluido_pos': { label: 'Concluído +', color: 'success' },
          'concluido_neg': { label: 'Concluído -', color: 'destructive' },
          'sem_interesse_def': { label: 'Sem Interesse', color: 'destructive' },
          'sem_contato': { label: 'Sem Contato', color: 'destructive' },
          'sem_interesse_momento': { label: 'Sem Interesse Agora', color: 'warning' }
        };
        const config = stageConfig[value as keyof typeof stageConfig] || { label: value, color: 'secondary' };
        return <Badge variant={config.color as any}>{config.label}</Badge>;
      }
    },
    {
      key: 'iqs' as keyof Lead,
      title: 'IQS',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => value ? `${value.toFixed(1)}` : '-'
    }
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Análise de Performance</h1>
        <p className="text-muted-foreground">
          Acompanhe os KPIs e métricas dos scouters em tempo real
        </p>
      </div>

      {/* Filters */}
      <FilterHeader 
        filters={filters}
        onFiltersChange={setFilters}
        loading={loading}
        showAIAnalysis={true}
      />

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KPICard
          title="Total de Fichas"
          value={mockKPIs.total_fichas}
          format="number"
          trend={12.5}
          icon={<Users className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="% Com Foto"
          value={mockKPIs.pct_com_foto}
          format="percentage"
          trend={2.1}
          variant="forte"
          icon={<Camera className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="% Confirmadas WhatsApp"
          value={mockKPIs.pct_confirmadas}
          format="percentage"
          trend={-1.3}
          icon={<MessageCircle className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="% Conseguiu Contato"
          value={mockKPIs.pct_contato}
          format="percentage"
          trend={5.7}
          variant="elite"
          icon={<Phone className="h-4 w-4" />}
          loading={loading}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KPICard
          title="% Agendadas"
          value={mockKPIs.pct_agendadas}
          format="percentage"
          trend={8.2}
          icon={<Calendar className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="% Compareceu"
          value={mockKPIs.pct_compareceu}
          format="percentage"
          trend={-2.8}
          variant="warning"
          icon={<CheckCircle className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="% Concluído Positivo"
          value={mockKPIs.pct_concluido_pos}
          format="percentage"
          trend={4.1}
          variant="elite"
          icon={<ThumbsUp className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="IQS Médio"
          value={mockKPIs.iqs_medio}
          format="number"
          trend={1.8}
          icon={<Target className="h-4 w-4" />}
          loading={loading}
        />
      </div>

      {/* Additional KPIs Row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KPICard
          title="% Interesse (não agendado)"
          value={mockKPIs.pct_interesse}
          format="percentage"
          trend={-0.5}
          icon={<Eye className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="% Concluído Negativo"  
          value={mockKPIs.pct_concluido_neg}
          format="percentage"
          trend={-3.2}
          variant="danger"
          icon={<ThumbsDown className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="% Sem Interesse Definitivo"
          value={mockKPIs.pct_sem_interesse_def}
          format="percentage"
          trend={-1.8}
          variant="danger"
          icon={<AlertTriangle className="h-4 w-4" />}
          loading={loading}
        />
        <KPICard
          title="% Sem Contato"
          value={mockKPIs.pct_sem_contato}
          format="percentage"
          trend={-4.1}
          variant="danger"
          icon={<PhoneMissed className="h-4 w-4" />}
          loading={loading}
        />
      </div>

      {/* Data Tables */}
      <Tabs defaultValue="scouters" className="space-y-4">
        <TabsList>
          <TabsTrigger value="scouters">Ranking de Scouters</TabsTrigger>
          <TabsTrigger value="leads">Tabela Master de Fichas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="scouters" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Ranking de Performance dos Scouters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <DataTable
                data={mockScouterMetrics}
                columns={scouterColumns}
                loading={loading}
                exportFilename="ranking-scouters"
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leads" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Tabela Master de Fichas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <DataTable
                data={mockLeads}
                columns={leadColumns}
                loading={loading}
                exportFilename="fichas-master"
                pagination={{
                  page: 1,
                  limit: 50,
                  total: 15420
                }}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}