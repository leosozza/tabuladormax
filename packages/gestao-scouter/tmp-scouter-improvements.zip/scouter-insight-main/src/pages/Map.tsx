import React, { useState, useEffect } from 'react';
import { MapPin, Layers, Users, Navigation, Zap, TrendingUp } from 'lucide-react';
import { FilterHeader } from '@/components/shared/FilterHeader';
import { KPICard } from '@/components/ui/kpi-card';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { AnalyticsFilters, HeatmapBucket, GeoCluster } from '@/types/scouter';

// Mock geo data
const mockHeatmapData: HeatmapBucket[] = [
  { h3_index: '87283082b7fffff', count: 145, lat: -23.5505, lng: -46.6333 }, // São Paulo Centro
  { h3_index: '87283082b3fffff', count: 89, lat: -23.5629, lng: -46.6544 }, // Vila Madalena
  { h3_index: '87283082bbfffff', count: 67, lat: -23.5475, lng: -46.6361 }, // República
  { h3_index: '87283082a7fffff', count: 123, lat: -23.5347, lng: -46.6426 }, // Jardins
  { h3_index: '87283082a3fffff', count: 98, lat: -23.5781, lng: -46.6517 }, // Pinheiros
];

const mockScouterLocations = [
  {
    scouter_id: '1',
    scouter_name: 'João Silva',
    lat: -23.5505,
    lng: -46.6333,
    accuracy: 12,
    timestamp: '2024-01-15T14:30:00Z',
    leads_nearby: 23,
    region: 'Centro'
  },
  {
    scouter_id: '2',
    scouter_name: 'Maria Santos',
    lat: -23.5629,
    lng: -46.6544,
    accuracy: 8,
    timestamp: '2024-01-15T14:25:00Z',
    leads_nearby: 15,
    region: 'Vila Madalena'
  },
  {
    scouter_id: '3',
    scouter_name: 'Pedro Costa',
    lat: -23.5781,
    lng: -46.6517,
    accuracy: 15,
    timestamp: '2024-01-15T14:20:00Z',
    leads_nearby: 31,
    region: 'Pinheiros'
  }
];

const mockRegionStats = [
  {
    region: 'Centro',
    total_fichas: 1450,
    pct_compareceu: 22.3,
    pct_confirmadas: 78.9,
    scouters_ativos: 5,
    densidade: 'Alta'
  },
  {
    region: 'Vila Madalena',
    total_fichas: 890,
    pct_compareceu: 19.1,
    pct_confirmadas: 82.1,
    scouters_ativos: 3,
    densidade: 'Média'
  },
  {
    region: 'Pinheiros',
    total_fichas: 1230,
    pct_compareceu: 25.7,
    pct_confirmadas: 75.4,
    scouters_ativos: 4,
    densidade: 'Alta'
  },
  {
    region: 'Jardins',
    total_fichas: 1120,
    pct_compareceu: 28.9,
    pct_confirmadas: 79.3,
    scouters_ativos: 4,
    densidade: 'Muito Alta'
  }
];

export default function Map() {
  const [filters, setFilters] = useState<AnalyticsFilters>({});
  const [loading, setLoading] = useState(false);
  const [showHeatmap, setShowHeatmap] = useState(true);
  const [showScouters, setShowScouters] = useState(true);
  const [showTrails, setShowTrails] = useState(false);

  // Mock map component since we can't embed a real map in this context
  const MapPlaceholder = () => (
    <div className="w-full h-[500px] bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 rounded-lg flex items-center justify-center relative overflow-hidden">
      {/* Mock map background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="grid grid-cols-8 h-full">
          {Array.from({ length: 64 }).map((_, i) => (
            <div key={i} className="border border-blue-200 dark:border-blue-800" />
          ))}
        </div>
      </div>
      
      {/* Mock heatmap areas */}
      {showHeatmap && mockHeatmapData.map((bucket, index) => (
        <div
          key={bucket.h3_index}
          className="absolute w-16 h-16 rounded-full"
          style={{
            left: `${20 + index * 15}%`,
            top: `${30 + (index % 3) * 20}%`,
            backgroundColor: `rgba(59, 130, 246, ${bucket.count / 200})`,
          }}
        />
      ))}
      
      {/* Mock scouter positions */}
      {showScouters && mockScouterLocations.map((scouter, index) => (
        <div
          key={scouter.scouter_id}
          className="absolute flex items-center justify-center"
          style={{
            left: `${25 + index * 20}%`,
            top: `${40 + (index % 2) * 15}%`,
          }}
        >
          <div className="w-4 h-4 bg-primary rounded-full border-2 border-white shadow-lg" />
          <Badge className="ml-2 text-xs bg-white text-primary border">
            {scouter.scouter_name.split(' ')[0]}
          </Badge>
        </div>
      ))}
      
      {/* Mock trails */}
      {showTrails && (
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <path
            d="M 25% 40% Q 45% 25% 65% 55%"
            stroke="rgba(59, 130, 246, 0.6)"
            strokeWidth="2"
            fill="none"
            strokeDasharray="5,5"
          />
          <path
            d="M 45% 55% Q 25% 70% 45% 85%"
            stroke="rgba(34, 197, 94, 0.6)"
            strokeWidth="2"
            fill="none"
            strokeDasharray="5,5"
          />
        </svg>
      )}
      
      <div className="text-center z-10">
        <MapPin className="h-12 w-12 mx-auto text-primary mb-2" />
        <p className="text-lg font-semibold text-primary">Mapa Interativo</p>
        <p className="text-sm text-muted-foreground">
          Visualização geográfica das fichas e scouters
        </p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Análise Geográfica</h1>
        <p className="text-muted-foreground">
          Visualize a distribuição geográfica de fichas e acompanhe os scouters em campo
        </p>
      </div>

      {/* Filters */}
      <FilterHeader 
        filters={filters}
        onFiltersChange={setFilters}
        loading={loading}
      />

      {/* Geographic KPIs */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KPICard
          title="Regiões Ativas"
          value={mockRegionStats.length}
          format="number"
          icon={<MapPin className="h-4 w-4" />}
        />
        <KPICard
          title="Scouters em Campo"
          value={mockScouterLocations.length}
          format="number"
          variant="forte"
          icon={<Users className="h-4 w-4" />}
        />
        <KPICard
          title="Concentração Média"
          value={98.3}
          format="number"
          subtitle="fichas por km²"
          icon={<Layers className="h-4 w-4" />}
        />
        <KPICard
          title="Cobertura Geográfica"
          value={87.2}
          format="percentage"
          variant="elite"
          icon={<Navigation className="h-4 w-4" />}
        />
      </div>

      {/* Map Controls and Visualization */}
      <div className="grid gap-6 lg:grid-cols-4">
        {/* Map Area */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Mapa de Calor e Posições
                </CardTitle>
                
                {/* Map Layer Controls */}
                <div className="flex flex-wrap gap-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="heatmap"
                      checked={showHeatmap}
                      onCheckedChange={setShowHeatmap}
                    />
                    <Label htmlFor="heatmap" className="text-sm">Heatmap</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="scouters"
                      checked={showScouters}
                      onCheckedChange={setShowScouters}
                    />
                    <Label htmlFor="scouters" className="text-sm">Scouters</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="trails"
                      checked={showTrails}
                      onCheckedChange={setShowTrails}
                    />
                    <Label htmlFor="trails" className="text-sm">Trilhas</Label>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <MapPlaceholder />
            </CardContent>
          </Card>
        </div>

        {/* Sidebar with Stats */}
        <div className="space-y-4">
          {/* Active Scouters */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                <Users className="h-4 w-4" />
                Scouters Ativos
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {mockScouterLocations.map((scouter) => (
                <div key={scouter.scouter_id} className="flex items-center justify-between p-2 rounded bg-muted/30">
                  <div className="flex-1">
                    <div className="font-medium text-sm">{scouter.scouter_name}</div>
                    <div className="text-xs text-muted-foreground">{scouter.region}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{scouter.leads_nearby}</div>
                    <div className="text-xs text-muted-foreground">fichas</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Heatmap Legend */}
          {showHeatmap && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  Densidade
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-blue-200" />
                  <span className="text-xs">Baixa (0-50)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-blue-400" />
                  <span className="text-xs">Média (51-100)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-blue-600" />
                  <span className="text-xs">Alta (101-150)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-blue-800" />
                  <span className="text-xs">Muito Alta (151+)</span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Privacy Notice */}
          <Alert>
            <Navigation className="h-4 w-4" />
            <AlertDescription className="text-xs">
              As posições são aproximadas por questões de privacidade. Precisão reduzida para 3-4 casas decimais.
            </AlertDescription>
          </Alert>
        </div>
      </div>

      {/* Regional Analysis Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Análise por Região
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2 font-semibold">Região</th>
                  <th className="text-right p-2 font-semibold">Total Fichas</th>
                  <th className="text-right p-2 font-semibold">% Compareceu</th>
                  <th className="text-right p-2 font-semibold">% Confirmadas</th>
                  <th className="text-center p-2 font-semibold">Scouters</th>
                  <th className="text-center p-2 font-semibold">Densidade</th>
                </tr>
              </thead>
              <tbody>
                {mockRegionStats.map((region, index) => (
                  <tr key={index} className="border-b hover:bg-muted/30">
                    <td className="p-2 font-medium">{region.region}</td>
                    <td className="p-2 text-right">{region.total_fichas.toLocaleString('pt-BR')}</td>
                    <td className="p-2 text-right">{region.pct_compareceu.toFixed(1)}%</td>
                    <td className="p-2 text-right">{region.pct_confirmadas.toFixed(1)}%</td>
                    <td className="p-2 text-center">
                      <Badge variant="outline">{region.scouters_ativos}</Badge>
                    </td>
                    <td className="p-2 text-center">
                      <Badge variant={
                        region.densidade === 'Muito Alta' ? 'destructive' :
                        region.densidade === 'Alta' ? 'secondary' :
                        region.densidade === 'Média' ? 'secondary' : 'outline'
                      }>
                        {region.densidade}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}