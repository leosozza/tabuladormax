import React, { useState } from 'react';
import { DollarSign, Users, Calculator, FileText, CheckCircle, AlertCircle, Clock, Download } from 'lucide-react';
import { FilterHeader } from '@/components/shared/FilterHeader';
import { KPICard } from '@/components/ui/kpi-card';
import { DataTable } from '@/components/shared/DataTable';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import type { AnalyticsFilters, PaymentItem, Payment } from '@/types/scouter';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// Mock data
const mockPaymentSummary = {
  total_fichas_elegiveis: 8450,
  valor_total_fichas: 42250.00,
  valor_total_ajuda_custo: 1850.00,
  valor_total_geral: 44100.00,
  scouters_elegiveis: 15,
  fichas_pagas: 6230,
  valor_pago: 31150.00,
  fichas_pendentes: 2220,
  valor_pendente: 12950.00
};

const mockScouterPayments = [
  {
    scouter_id: '1',
    scouter_name: 'João Silva',
    tier: 'S3',
    total_fichas: 450,
    fichas_elegiveis: 380,
    valor_por_ficha: 7.00,
    valor_fichas: 2660.00,
    ajuda_custo: 50.00,
    total_a_pagar: 2710.00,
    status: 'A pagar' as const,
    pct_elegibilidade: 84.4,
    meta_mensal: 850,
    performance: 53.0
  },
  {
    scouter_id: '2', 
    scouter_name: 'Maria Santos',
    tier: 'S2',
    total_fichas: 320,
    fichas_elegiveis: 290,
    valor_por_ficha: 5.00,
    valor_fichas: 1450.00,
    ajuda_custo: 40.00,
    total_a_pagar: 1490.00,
    status: 'Pago' as const,
    pct_elegibilidade: 90.6,
    meta_mensal: 500,
    performance: 64.0
  },
  {
    scouter_id: '3',
    scouter_name: 'Pedro Costa',
    tier: 'S1',
    total_fichas: 280,
    fichas_elegiveis: 220,
    valor_por_ficha: 4.00,
    valor_fichas: 880.00,
    ajuda_custo: 30.00,
    total_a_pagar: 910.00,
    status: 'A pagar' as const,
    pct_elegibilidade: 78.6,
    meta_mensal: 500,
    performance: 56.0
  }
];

const mockPayments: Payment[] = [
  {
    id: '1',
    ref: 'PAG-2024-001',
    period_start: '2024-01-01',
    period_end: '2024-01-31',
    created_at: '2024-02-01T10:00:00Z',
    paid_at: '2024-02-03T14:30:00Z',
    notes: 'Pagamento janeiro 2024'
  },
  {
    id: '2',
    ref: 'PAG-2024-002', 
    period_start: '2024-02-01',
    period_end: '2024-02-29',
    created_at: '2024-03-01T09:15:00Z',
    notes: 'Pagamento fevereiro 2024'
  }
];

interface ScouterPayment {
  scouter_id: string;
  scouter_name: string;
  tier: string;
  total_fichas: number;
  fichas_elegiveis: number;
  valor_por_ficha: number;
  valor_fichas: number;
  ajuda_custo: number;
  total_a_pagar: number;
  status: 'A pagar' | 'Pago';
  pct_elegibilidade: number;
  meta_mensal: number;
  performance: number;
}

export default function Payments() {
  const [filters, setFilters] = useState<AnalyticsFilters>({});
  const [loading, setLoading] = useState(false);
  const [generatePaymentLoading, setGeneratePaymentLoading] = useState(false);
  const { toast } = useToast();

  const handleGeneratePayment = async () => {
    setGeneratePaymentLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Lote de pagamento gerado",
        description: "O lote foi criado com sucesso. Revise antes de confirmar.",
      });
    } catch (error) {
      toast({
        title: "Erro ao gerar lote",
        description: "Ocorreu um erro ao gerar o lote de pagamento.",
        variant: "destructive",
      });
    } finally {
      setGeneratePaymentLoading(false);
    }
  };

  const handleMarkAsPaid = async (scouterId: string) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Pagamento confirmado",
        description: "O pagamento foi marcado como pago com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao confirmar pagamento",
        description: "Ocorreu um erro ao marcar o pagamento como pago.",
        variant: "destructive",
      });
    }
  };

  const scouterPaymentColumns = [
    {
      key: 'scouter_name' as keyof ScouterPayment,
      title: 'Scouter',
      sortable: true,
      render: (value: string, row: ScouterPayment) => (
        <div className="flex flex-col">
          <span className="font-medium">{value}</span>
          <Badge variant="outline" className="w-fit text-xs">
            {row.tier}
          </Badge>
        </div>
      )
    },
    {
      key: 'total_fichas' as keyof ScouterPayment,
      title: 'Total Fichas',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => value.toLocaleString('pt-BR')
    },
    {
      key: 'fichas_elegiveis' as keyof ScouterPayment,
      title: 'Elegíveis',
      sortable: true,
      align: 'right' as const,
      render: (value: number, row: ScouterPayment) => (
        <div className="flex flex-col items-end">
          <span className="font-medium">{value.toLocaleString('pt-BR')}</span>
          <span className="text-xs text-muted-foreground">
            {row.pct_elegibilidade.toFixed(1)}%
          </span>
        </div>
      )
    },
    {
      key: 'valor_por_ficha' as keyof ScouterPayment,
      title: 'Valor/Ficha',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      }).format(value)
    },
    {
      key: 'valor_fichas' as keyof ScouterPayment,
      title: 'Valor Fichas',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      }).format(value)
    },
    {
      key: 'ajuda_custo' as keyof ScouterPayment,
      title: 'Ajuda Custo',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      }).format(value)
    },
    {
      key: 'total_a_pagar' as keyof ScouterPayment,
      title: 'Total',
      sortable: true,
      align: 'right' as const,
      render: (value: number) => (
        <span className="font-semibold text-primary">
          {new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
          }).format(value)}
        </span>
      )
    },
    {
      key: 'performance' as keyof ScouterPayment,
      title: 'Meta Progress',
      render: (value: number, row: ScouterPayment) => (
        <div className="flex items-center gap-2 min-w-[120px]">
          <Progress value={value} className="flex-1 h-2" />
          <span className="text-xs font-medium min-w-[40px]">
            {value.toFixed(0)}%
          </span>
        </div>
      )
    },
    {
      key: 'status' as keyof ScouterPayment,
      title: 'Status',
      render: (value: string, row: ScouterPayment) => (
        <div className="flex flex-col gap-2">
          <Badge variant={value === 'Pago' ? 'secondary' : 'outline'}>
            {value}
          </Badge>
          {value === 'A pagar' && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleMarkAsPaid(row.scouter_id)}
            >
              Marcar Pago
            </Button>
          )}
        </div>
      )
    }
  ];

  const paymentHistoryColumns = [
    {
      key: 'ref' as keyof Payment,
      title: 'Referência',
      sortable: true,
      render: (value: string) => (
        <span className="font-mono text-sm">{value}</span>
      )
    },
    {
      key: 'period_start' as keyof Payment,
      title: 'Período',
      render: (value: string, row: Payment) => (
        <span>
          {format(new Date(value), 'MMM/yyyy', { locale: ptBR })}
        </span>
      )
    },
    {
      key: 'created_at' as keyof Payment,
      title: 'Criado em',
      sortable: true,
      render: (value: string) => format(new Date(value), 'dd/MM/yyyy HH:mm', { locale: ptBR })
    },
    {
      key: 'paid_at' as keyof Payment,
      title: 'Status',
      render: (value: string | undefined) => (
        <Badge variant={value ? 'secondary' : 'outline'}>
          {value ? 'Pago' : 'Pendente'}
        </Badge>
      )
    },
    {
      key: 'notes' as keyof Payment,
      title: 'Observações',
      render: (value: string) => (
        <span className="text-sm text-muted-foreground">
          {value || '-'}
        </span>
      )
    }
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Controle de Pagamentos</h1>
        <p className="text-muted-foreground">
          Gerencie os pagamentos de fichas e ajuda de custo dos scouters
        </p>
      </div>

      {/* Filters */}
      <FilterHeader 
        filters={filters}
        onFiltersChange={setFilters}
        loading={loading}
      />

      {/* Summary KPIs */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KPICard
          title="Fichas Elegíveis"
          value={mockPaymentSummary.total_fichas_elegiveis}
          format="number"
          icon={<CheckCircle className="h-4 w-4" />}
          variant="elite"
        />
        <KPICard
          title="Valor Total Fichas"
          value={mockPaymentSummary.valor_total_fichas}
          format="currency"
          icon={<DollarSign className="h-4 w-4" />}
        />
        <KPICard
          title="Ajuda de Custo"
          value={mockPaymentSummary.valor_total_ajuda_custo}
          format="currency"
          icon={<Calculator className="h-4 w-4" />}
        />
        <KPICard
          title="Total Geral"
          value={mockPaymentSummary.valor_total_geral}
          format="currency"
          icon={<FileText className="h-4 w-4" />}
          variant="forte"
        />
      </div>

      {/* Action Buttons */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="space-y-1">
            <h3 className="font-semibold">Ações de Pagamento</h3>
            <p className="text-sm text-muted-foreground">
              Gere lotes de pagamento e confirme os valores antes do processamento
            </p>
          </div>
          <div className="flex gap-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <FileText className="h-4 w-4 mr-2" />
                  Ver Prévia
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Prévia do Lote de Pagamento</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Esta é uma prévia. Os valores finais podem variar após a confirmação.
                    </AlertDescription>
                  </Alert>
                  <DataTable
                    data={mockScouterPayments}
                    columns={scouterPaymentColumns.slice(0, -1)} // Remove action column
                    exportable={false}
                    searchable={false}
                  />
                </div>
              </DialogContent>
            </Dialog>
            
            <Button 
              onClick={handleGeneratePayment}
              disabled={generatePaymentLoading}
              className="btn-dashboard"
            >
              {generatePaymentLoading ? (
                <Clock className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Calculator className="h-4 w-4 mr-2" />
              )}
              Gerar Lote
            </Button>
          </div>
        </div>
      </Card>

      {/* Payment Tables */}
      <Tabs defaultValue="current" className="space-y-4">
        <TabsList>
          <TabsTrigger value="current">Pagamentos Atual</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
        </TabsList>
        
        <TabsContent value="current" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Resumo por Scouter
                </CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Exportar Planilha
                  </Button>
                  <Button variant="outline" size="sm">
                    <FileText className="h-4 w-4 mr-2" />
                    Gerar Recibo
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Payment Rules Alert */}
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Regras de Elegibilidade:</strong> Exigir foto ✓ | Exigir confirmação WhatsApp ✓ | Multiplicadores por etapa aplicados
                  </AlertDescription>
                </Alert>

                <DataTable
                  data={mockScouterPayments}
                  columns={scouterPaymentColumns}
                  loading={loading}
                  exportFilename="pagamentos-scouters"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Histórico de Pagamentos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <DataTable
                data={mockPayments}
                columns={paymentHistoryColumns}
                loading={loading}
                exportFilename="historico-pagamentos"
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}