// Tipos principais para o sistema Scouter Intelligence

export type LeadStage = 
  | 'novo'
  | 'confirmado'
  | 'interesse'
  | 'agendado'
  | 'compareceu'
  | 'concluido_pos'
  | 'concluido_neg'
  | 'sem_interesse_def'
  | 'sem_contato'
  | 'sem_interesse_momento';

export type ScouterTier = 'S1' | 'S2' | 'S3'; // Júnior, Pleno, Sênior
export type ScouterClass = 'Elite' | 'Forte' | 'Estável' | 'Em desenvolvimento' | 'Atenção';
export type PaymentItemType = 'ficha' | 'ajuda_custo';
export type PaymentStatus = 'A pagar' | 'Pago';
export type SyncStatus = 'running' | 'success' | 'error';

// Interfaces principais

export interface Project {
  id: string;
  name: string;
  is_active: boolean;
  created_at: string;
}

export interface Scouter {
  id: string;
  name: string;
  phone?: string;
  active: boolean;
  created_at: string;
}

export interface ScouterClassification {
  id: string;
  scouter_id: string;
  project_id?: string;
  valor_por_ficha: number;
  ajuda_custo: number;
  meta_fichas: number;
  pct_min_interesse: number;
  pct_max_sem_contato: number;
  pct_min_fotos: number;
  pct_min_agendadas: number;
  pct_min_compareceu: number;
  nivel?: ScouterTier;
  created_at: string;
}

export interface ProjectIndicatorWeights {
  id: string;
  project_id: string;
  scouter_id?: string; // null = padrão do projeto
  peso_foto: number;
  peso_confirmada: number;
  peso_contato: number;
  peso_interesse: number;
  peso_agendado: number;
  peso_compareceu: number;
  peso_concluido_pos: number;
  peso_concluido_neg: number;
  peso_sem_interesse_def: number;
  peso_sem_contato: number;
  peso_sem_interesse_momento: number;
}

export interface ProjectPaymentMultipliers {
  id: string;
  project_id: string;
  stage: LeadStage;
  multiplier: number;
}

export interface Lead {
  id: string;
  created_at: string;
  project_id?: string;
  scouter_id?: string;
  responsavel?: string;
  modelo?: string;
  idade?: number;
  observacoes?: string;
  has_photo: boolean;
  confirmed_whatsapp: boolean;
  contacted: boolean;
  stage: LeadStage;
  lat?: number;
  lng?: number;
  accuracy?: number;
  h3_res7?: string;
  iqs?: number;
  bitrix_id?: string;
  payment_item_id?: string;
}

export interface LeadStageHistory {
  id: string;
  lead_id: string;
  from_stage?: LeadStage;
  to_stage: LeadStage;
  changed_at: string;
  changed_by?: string;
}

export interface ScouterCheckin {
  id: string;
  scouter_id: string;
  ts: string;
  lat: number;
  lng: number;
  accuracy?: number;
  h3_res7?: string;
}

export interface Payment {
  id: string;
  ref?: string;
  period_start: string;
  period_end: string;
  project_id?: string;
  created_at: string;
  created_by?: string;
  approved_by?: string;
  paid_at?: string;
  paid_by?: string;
  notes?: string;
}

export interface PaymentItem {
  id: string;
  payment_id: string;
  scouter_id?: string;
  type: PaymentItemType;
  lead_id?: string;
  amount: number;
  multiplier?: number;
  base_amount?: number;
  eligible: boolean;
}

export interface BitrixSyncRun {
  id: string;
  started_at: string;
  completed_at?: string;
  status: SyncStatus;
  sync_type: string;
  records_processed: number;
  records_created: number;
  records_updated: number;
  records_failed: number;
  error_message?: string;
  user_id?: string;
}

export interface ScouterGoal {
  id: string;
  scouter_name: string;
  period_start: string;
  period_end: string;
  weekly_goal?: number;
  monthly_goal?: number;
  source: string;
  created_at: string;
}

// KPIs e Analytics

export interface KPIData {
  total_fichas: number;
  pct_com_foto: number;
  pct_confirmadas: number;
  pct_contato: number;
  pct_agendadas: number;
  pct_compareceu: number;
  pct_interesse: number;
  pct_concluido_pos: number;
  pct_concluido_neg: number;
  pct_sem_interesse_def: number;
  pct_sem_contato: number;
  pct_sem_interesse_momento: number;
  iqs_medio: number;
}

export interface ScouterMetrics extends KPIData {
  scouter_id: string;
  scouter_name: string;
  leads_total: number;
  fichas_sim: number;
  taxa_ficha: number;
  presencas_sim: number;
  taxa_presenca: number;
  dias_ate_conf_media: number;
  media_diaria_ult14d: number;
  taxa_conf_14d: number;
  elegivel: boolean;
  score_conversao: number;
  score_velocidade: number;
  score_volume: number;
  score_presenca: number;
  score_composto: number;
  classe: ScouterClass;
  tier_name?: string;
}

export interface ScouterProjection {
  scouter_id: string;
  scouter_name: string;
  business_days_left: number;
  proj_conf_restantes: number;
  proj_presencas_restantes: number;
  meta_mensal?: number;
  gap_meta: number;
  base_rate: number;
}

// Filtros

export interface AnalyticsFilters {
  startDate?: string;
  endDate?: string;
  scouterIds?: string[];
  projectIds?: string[];
}

// Heatmap e Geolocalização

export interface HeatmapBucket {
  h3_index: string;
  count: number;
  lat: number;
  lng: number;
}

export interface GeoCluster {
  lat: number;
  lng: number;
  count: number;
  leads?: Lead[];
}

// API Responses

export interface ApiResponse<T> {
  data: T;
  success: boolean;
  error?: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Bitrix Integration

export interface BitrixConfig {
  base_url: string;
  auth_mode: 'webhook' | 'oauth';
  webhook_user_id?: string;
  webhook_token?: string;
  client_id?: string;
  client_secret?: string;
  refresh_token?: string;
}

export interface BitrixLead {
  id: string;
  title?: string;
  date_create: string;
  stage_id?: string;
  name?: string;
  last_name?: string;
  phone?: string;
  mobile_phone?: string;
  email?: string;
  // Campos customizados do Bitrix mapeados para nosso sistema
  [key: string]: any;
}

// Import/Export

export interface ImportMapping {
  sourceColumn: string;
  targetField: string;
  required: boolean;
}

export interface ImportResult {
  total_processed: number;
  success_count: number;
  error_count: number;
  errors: string[];
}

// UI Component Props

export interface FilterHeaderProps {
  filters: AnalyticsFilters;
  onFiltersChange: (filters: AnalyticsFilters) => void;
  loading?: boolean;
}

export interface KPICardProps {
  title: string;
  value: string | number;
  trend?: number;
  format?: 'number' | 'percentage' | 'currency';
  variant?: 'default' | 'elite' | 'forte' | 'warning' | 'danger';
}

export interface DataTableProps<T> {
  data: T[];
  columns: any[];
  loading?: boolean;
  pagination?: {
    page: number;
    limit: number;
    total: number;
  };
  onPaginationChange?: (page: number, limit: number) => void;
  exportable?: boolean;
  exportFilename?: string;
}