// Database type definitions for Supabase
export interface Database {
  public: {
    Tables: {
      projects: {
        Row: {
          id: string;
          name: string;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          is_active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          is_active?: boolean;
          created_at?: string;
        };
      };
      scouters: {
        Row: {
          id: string;
          name: string;
          phone: string | null;
          active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          phone?: string | null;
          active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          phone?: string | null;
          active?: boolean;
          created_at?: string;
        };
      };
      scouter_classifications: {
        Row: {
          id: string;
          scouter_id: string;
          project_id: string | null;
          valor_por_ficha: number;
          ajuda_custo: number;
          meta_fichas: number;
          pct_min_interesse: number;
          pct_max_sem_contato: number;
          pct_min_fotos: number;
          pct_min_agendadas: number;
          pct_min_compareceu: number;
          nivel: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          scouter_id: string;
          project_id?: string | null;
          valor_por_ficha: number;
          ajuda_custo: number;
          meta_fichas: number;
          pct_min_interesse?: number;
          pct_max_sem_contato?: number;
          pct_min_fotos?: number;
          pct_min_agendadas?: number;
          pct_min_compareceu?: number;
          nivel?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          scouter_id?: string;
          project_id?: string | null;
          valor_por_ficha?: number;
          ajuda_custo?: number;
          meta_fichas?: number;
          pct_min_interesse?: number;
          pct_max_sem_contato?: number;
          pct_min_fotos?: number;
          pct_min_agendadas?: number;
          pct_min_compareceu?: number;
          nivel?: string | null;
          created_at?: string;
        };
      };
      project_indicator_weights: {
        Row: {
          id: string;
          project_id: string;
          scouter_id: string | null;
          peso_foto: number;
          peso_confirmada: number;
          peso_contato: number;
          peso_interesse: number;
          peso_agendado: number;
          peso_compareceu: number;
          peso_concluido_pos: number;
          peso_concluido_neg: number;
          peso_sem_interesse_def: number;
          peso_sem_contato: number;
          peso_sem_interesse_momento: number;
        };
        Insert: {
          id?: string;
          project_id: string;
          scouter_id?: string | null;
          peso_foto?: number;
          peso_confirmada?: number;
          peso_contato?: number;
          peso_interesse?: number;
          peso_agendado?: number;
          peso_compareceu?: number;
          peso_concluido_pos?: number;
          peso_concluido_neg?: number;
          peso_sem_interesse_def?: number;
          peso_sem_contato?: number;
          peso_sem_interesse_momento?: number;
        };
        Update: {
          id?: string;
          project_id?: string;
          scouter_id?: string | null;
          peso_foto?: number;
          peso_confirmada?: number;
          peso_contato?: number;
          peso_interesse?: number;
          peso_agendado?: number;
          peso_compareceu?: number;
          peso_concluido_pos?: number;
          peso_concluido_neg?: number;
          peso_sem_interesse_def?: number;
          peso_sem_contato?: number;
          peso_sem_interesse_momento?: number;
        };
      };
      project_payment_multipliers: {
        Row: {
          id: string;
          project_id: string;
          stage: string;
          multiplier: number;
        };
        Insert: {
          id?: string;
          project_id: string;
          stage: string;
          multiplier: number;
        };
        Update: {
          id?: string;
          project_id?: string;
          stage?: string;
          multiplier?: number;
        };
      };
      leads: {
        Row: {
          id: string;
          created_at: string;
          project_id: string | null;
          scouter_id: string | null;
          responsavel: string | null;
          modelo: string | null;
          idade: number | null;
          observacoes: string | null;
          has_photo: boolean;
          confirmed_whatsapp: boolean;
          contacted: boolean;
          stage: string;
          lat: number | null;
          lng: number | null;
          accuracy: number | null;
          h3_res7: string | null;
          iqs: number | null;
          bitrix_id: string | null;
          payment_item_id: string | null;
        };
        Insert: {
          id?: string;
          created_at?: string;
          project_id?: string | null;
          scouter_id?: string | null;
          responsavel?: string | null;
          modelo?: string | null;
          idade?: number | null;
          observacoes?: string | null;
          has_photo?: boolean;
          confirmed_whatsapp?: boolean;
          contacted?: boolean;
          stage?: string;
          lat?: number | null;
          lng?: number | null;
          accuracy?: number | null;
          h3_res7?: string | null;
          iqs?: number | null;
          bitrix_id?: string | null;
          payment_item_id?: string | null;
        };
        Update: {
          id?: string;
          created_at?: string;
          project_id?: string | null;
          scouter_id?: string | null;
          responsavel?: string | null;
          modelo?: string | null;
          idade?: number | null;
          observacoes?: string | null;
          has_photo?: boolean;
          confirmed_whatsapp?: boolean;
          contacted?: boolean;
          stage?: string;
          lat?: number | null;
          lng?: number | null;
          accuracy?: number | null;
          h3_res7?: string | null;
          iqs?: number | null;
          bitrix_id?: string | null;
          payment_item_id?: string | null;
        };
      };
      lead_stage_history: {
        Row: {
          id: string;
          lead_id: string;
          from_stage: string | null;
          to_stage: string;
          changed_at: string;
          changed_by: string | null;
        };
        Insert: {
          id?: string;
          lead_id: string;
          from_stage?: string | null;
          to_stage: string;
          changed_at?: string;
          changed_by?: string | null;
        };
        Update: {
          id?: string;
          lead_id?: string;
          from_stage?: string | null;
          to_stage?: string;
          changed_at?: string;
          changed_by?: string | null;
        };
      };
      scouter_checkins: {
        Row: {
          id: string;
          scouter_id: string;
          ts: string;
          lat: number;
          lng: number;
          accuracy: number | null;
          h3_res7: string | null;
        };
        Insert: {
          id?: string;
          scouter_id: string;
          ts?: string;
          lat: number;
          lng: number;
          accuracy?: number | null;
          h3_res7?: string | null;
        };
        Update: {
          id?: string;
          scouter_id?: string;
          ts?: string;
          lat?: number;
          lng?: number;
          accuracy?: number | null;
          h3_res7?: string | null;
        };
      };
      payments: {
        Row: {
          id: string;
          ref: string | null;
          period_start: string;
          period_end: string;
          project_id: string | null;
          created_at: string;
          created_by: string | null;
          approved_by: string | null;
          paid_at: string | null;
          paid_by: string | null;
          notes: string | null;
        };
        Insert: {
          id?: string;
          ref?: string | null;
          period_start: string;
          period_end: string;
          project_id?: string | null;
          created_at?: string;
          created_by?: string | null;
          approved_by?: string | null;
          paid_at?: string | null;
          paid_by?: string | null;
          notes?: string | null;
        };
        Update: {
          id?: string;
          ref?: string | null;
          period_start?: string;
          period_end?: string;
          project_id?: string | null;
          created_at?: string;
          created_by?: string | null;
          approved_by?: string | null;
          paid_at?: string | null;
          paid_by?: string | null;
          notes?: string | null;
        };
      };
      payment_items: {
        Row: {
          id: string;
          payment_id: string;
          scouter_id: string | null;
          type: string;
          lead_id: string | null;
          amount: number;
          multiplier: number | null;
          base_amount: number | null;
          eligible: boolean;
        };
        Insert: {
          id?: string;
          payment_id: string;
          scouter_id?: string | null;
          type: string;
          lead_id?: string | null;
          amount: number;
          multiplier?: number | null;
          base_amount?: number | null;
          eligible?: boolean;
        };
        Update: {
          id?: string;
          payment_id?: string;
          scouter_id?: string | null;
          type?: string;
          lead_id?: string | null;
          amount?: number;
          multiplier?: number | null;
          base_amount?: number | null;
          eligible?: boolean;
        };
      };
      bitrix_sync_runs: {
        Row: {
          id: string;
          started_at: string;
          completed_at: string | null;
          status: string;
          sync_type: string;
          records_processed: number;
          records_created: number;
          records_updated: number;
          records_failed: number;
          error_message: string | null;
          user_id: string | null;
        };
        Insert: {
          id?: string;
          started_at?: string;
          completed_at?: string | null;
          status: string;
          sync_type: string;
          records_processed?: number;
          records_created?: number;
          records_updated?: number;
          records_failed?: number;
          error_message?: string | null;
          user_id?: string | null;
        };
        Update: {
          id?: string;
          started_at?: string;
          completed_at?: string | null;
          status?: string;
          sync_type?: string;
          records_processed?: number;
          records_created?: number;
          records_updated?: number;
          records_failed?: number;
          error_message?: string | null;
          user_id?: string | null;
        };
      };
      scouter_goals: {
        Row: {
          id: string;
          scouter_name: string;
          period_start: string;
          period_end: string;
          weekly_goal: number | null;
          monthly_goal: number | null;
          source: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          scouter_name: string;
          period_start: string;
          period_end: string;
          weekly_goal?: number | null;
          monthly_goal?: number | null;
          source?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          scouter_name?: string;
          period_start?: string;
          period_end?: string;
          weekly_goal?: number | null;
          monthly_goal?: number | null;
          source?: string;
          created_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      analytics_kpis: {
        Args: {
          start_date?: string;
          end_date?: string;
          scouter_ids?: string[];
          project_ids?: string[];
        };
        Returns: any;
      };
      get_scouter_ranking: {
        Args: {
          start_date?: string;
          end_date?: string;
          project_ids?: string[];
        };
        Returns: any;
      };
      get_scouter_projections: {
        Args: {
          target_month?: string;
        };
        Returns: any;
      };
      payments_generate: {
        Args: {
          period_start: string;
          period_end: string;
          project_id?: string;
          scouter_ids?: string[];
        };
        Returns: any;
      };
      payments_commit: {
        Args: {
          payment_id: string;
        };
        Returns: any;
      };
      payments_mark_paid: {
        Args: {
          payment_id: string;
          payment_metadata?: any;
        };
        Returns: any;
      };
      geo_heatmap: {
        Args: {
          start_date?: string;
          end_date?: string;
          project_ids?: string[];
          h3_res?: number;
        };
        Returns: any;
      };
      leads_search: {
        Args: {
          start_date?: string;
          end_date?: string;
          scouter_ids?: string[];
          project_ids?: string[];
          stage?: string;
          page?: number;
          limit?: number;
        };
        Returns: any;
      };
      schema_ensure: {
        Args: Record<PropertyKey, never>;
        Returns: any;
      };
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
}