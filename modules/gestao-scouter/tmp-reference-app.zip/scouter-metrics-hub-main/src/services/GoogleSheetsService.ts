interface GoogleSheetsConfig {
  apiKey: string;
  spreadsheetId: string;
  range: string;
}

interface SheetRow {
  [key: string]: string;
}

export class GoogleSheetsService {
  private static API_KEY_STORAGE_KEY = 'google_sheets_api_key';
  private static SPREADSHEET_ID_STORAGE_KEY = 'google_sheets_spreadsheet_id';

  static saveApiKey(apiKey: string): void {
    localStorage.setItem(this.API_KEY_STORAGE_KEY, apiKey);
  }

  static getApiKey(): string | null {
    return localStorage.getItem(this.API_KEY_STORAGE_KEY);
  }

  static saveSpreadsheetId(spreadsheetId: string): void {
    localStorage.setItem(this.SPREADSHEET_ID_STORAGE_KEY, spreadsheetId);
  }

  static getSpreadsheetId(): string | null {
    return localStorage.getItem(this.SPREADSHEET_ID_STORAGE_KEY);
  }

  static extractSpreadsheetId(url: string): string | null {
    const match = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    return match ? match[1] : null;
  }

  static async fetchSheetData(range: string = 'A:Z'): Promise<{ success: boolean; data?: any[]; error?: string }> {
    const spreadsheetId = this.getSpreadsheetId();

    if (!spreadsheetId) {
      return { success: false, error: 'Spreadsheet ID not configured' };
    }

    try {
      // Try without API key first for public sheets
      let url = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/gviz/tq?tqx=out:csv&gid=452792639`;
      
      let response = await fetch(url);
      
      // If that fails, try with API key
      if (!response.ok) {
        const apiKey = this.getApiKey();
        if (!apiKey) {
          return { success: false, error: 'Google Sheets API key not configured and sheet is not public' };
        }
        url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}?key=${apiKey}`;
        response = await fetch(url);
      }
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        return { 
          success: false, 
          error: errorData?.error?.message || `HTTP ${response.status}: ${response.statusText}` 
        };
      }

      let data: any;
      const contentType = response.headers.get('content-type');
      
      if (contentType?.includes('application/json')) {
        // Google Sheets API response
        data = await response.json();
        if (!data.values || data.values.length === 0) {
          return { success: false, error: 'No data found in the spreadsheet' };
        }
        
        // Convert to objects using first row as headers
        const headers = data.values[0];
        const rows = data.values.slice(1).map((row: string[]) => {
          const obj: SheetRow = {};
          headers.forEach((header: string, index: number) => {
            obj[header] = row[index] || '';
          });
          return obj;
        });

        return { success: true, data: rows };
      } else {
        // CSV response from public sheet
        const csvText = await response.text();
        const lines = csvText.split('\n').filter(line => line.trim());
        
        if (lines.length === 0) {
          return { success: false, error: 'No data found in the spreadsheet' };
        }
        
        // Parse CSV manually
        const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());
        const rows = lines.slice(1).map(line => {
          const values = line.split(',').map(v => v.replace(/"/g, '').trim());
          const obj: SheetRow = {};
          headers.forEach((header, index) => {
            obj[header] = values[index] || '';
          });
          return obj;
        });

        return { success: true, data: rows };
      }
    } catch (error) {
      console.error('Error fetching sheet data:', error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch data from Google Sheets' 
      };
    }
  }

  static async testConnection(): Promise<boolean> {
    const result = await this.fetchSheetData('A1:A1');
    return result.success;
  }

  static convertToLeads(sheetData: SheetRow[]): any[] {
    return sheetData.map((row) => {
      // Parse location coordinates
      const location = this.parseLocation(row['Localizacao'] || '');
      
      return {
        id: row['ID'] || '',
        created_at: this.parseDate(row['Data_criacao_Ficha'] || row['Criado'] || ''),
        project_id: this.mapProjectName(row['Projetos'] || ''),
        scouter_id: this.mapScouterName(row['Scouter'] || ''),
        responsavel: row['Nome'] || '',
        modelo: row['modelo'] || '',
        idade: parseInt(row['Idade'] || '0') || 0,
        observacoes: `Local: ${row['Local_da_Abordagem'] || ''} | Supervisor: ${row['Supervisor_do_Scouter'] || ''} | Funil: ${row['GERENCIAMENTOFUNIL'] || ''} | Etapa Funil: ${row['ETAPAFUNIL'] || ''}`,
        has_photo: this.parseBoolean(row['Cadastro_Existe_Foto'] || ''),
        confirmed_whatsapp: this.parseBoolean(row['Ficha_confirmada'] || ''),
        contacted: true, // Assume contacted if in system
        stage: this.mapStage(row['ETAPAFUNIL'] || row['Etapa'] || row['GERENCIAMENTOFUNIL'] || 'novo'),
        lat: location.lat,
        lng: location.lng,
        iqs: Math.random() * 100, // Calculate based on your business logic
        valor_ficha: this.parseMoneyValue(row['Valor_Ficha'] || ''),
        data_confirmacao: this.parseDate(row['Data_confirmacao_ficha'] || ''),
        presenca_confirmada: this.parseBoolean(row['Presenca_confirmada'] || ''),
        local_abordagem: row['Local_da_Abordagem'] || '',
        supervisor: row['Supervisor_do_Scouter'] || '',
      };
    });
  }

  private static parseBoolean(value: string): boolean {
    const lowerValue = value.toLowerCase().trim();
    return lowerValue === 'sim' || lowerValue === 'yes' || lowerValue === 'true' || 
           lowerValue === '1' || lowerValue === 'y' || lowerValue.includes('✳ sim');
  }

  private static mapStage(stage: string): string {
    const stageMapping: { [key: string]: string } = {
      'Lead a Qualificar': 'novo',
      'StandyBy': 'confirmado',
      'Qualificado': 'interesse',
      'Lead Qualificado': 'interesse',
      'Agendado': 'agendado',
      'Compareceu': 'compareceu',
      'Concluído Positivo': 'concluido_pos',
      'Concluído Negativo': 'concluido_neg',
      'Sem Interesse': 'sem_interesse_def',
      'Sem Contato': 'sem_contato',
      'Sem Interesse no Momento': 'sem_interesse_momento',
    };
    
    return stageMapping[stage] || 'novo';
  }

  private static parseLocation(locationStr: string): { lat: number; lng: number } {
    if (!locationStr || !locationStr.includes(',')) {
      // Sem localização válida na planilha → não mapear
      return {
        lat: Number.NaN,
        lng: Number.NaN,
      };
    }
    
    const [latStr, lngStr] = locationStr.split(',');
    const lat = parseFloat(latStr.trim());
    const lng = parseFloat(lngStr.trim());
    return {
      lat: isNaN(lat) ? Number.NaN : lat,
      lng: isNaN(lng) ? Number.NaN : lng,
    };
  }

  private static parseDate(dateStr: string): string {
    if (!dateStr || dateStr.trim() === '') return new Date().toISOString();
    
    try {
      // Handle Brazilian date format DD/MM/YYYY or DD/MM/YYYY HH:mm:ss
      const brazilianDateRegex = /(\d{1,2})\/(\d{1,2})\/(\d{4})(\s+\d{1,2}:\d{2}:\d{2})?/;
      const match = dateStr.match(brazilianDateRegex);
      
      if (match) {
        const [, day, month, year, time] = match;
        let dateString = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        
        if (time) {
          dateString += `T${time.trim()}:00.000Z`;
        } else {
          dateString += 'T00:00:00.000Z';
        }
        
        const parsedDate = new Date(dateString);
        if (isNaN(parsedDate.getTime())) {
          return new Date().toISOString();
        }
        return parsedDate.toISOString();
      }
      
      // Try direct parsing as fallback
      const directDate = new Date(dateStr);
      if (isNaN(directDate.getTime())) {
        return new Date().toISOString();
      }
      return directDate.toISOString();
    } catch (error) {
      console.warn('Error parsing date:', dateStr, error);
      return new Date().toISOString();
    }
  }

  private static parseMoneyValue(moneyStr: string): number {
    if (!moneyStr) return 0;
    // Remove R$, spaces, and convert comma to dot
    return parseFloat(moneyStr.replace(/[R$\s]/g, '').replace(',', '.')) || 0;
  }

  private static parseConfirmationStatus(status: string): boolean {
    const lowerStatus = status.toLowerCase().trim();
    return lowerStatus === 'sim' || lowerStatus === 'confirmada' || lowerStatus === 'confirmado';
  }

  private static mapProjectName(projectName: string): string {
    // Create a simple mapping - you might want to expand this
    return projectName || 'default';
  }

  private static mapScouterName(scouterName: string): string {
    // Return the actual scouter name instead of mapping to IDs
    return scouterName || 'unknown';
  }
}