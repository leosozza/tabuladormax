import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FilterState, KPIData } from '@/types/database';
import { useLeadsData } from '@/hooks/useLeadsData';
import { DataSyncStatus } from '@/components/common/DataSyncStatus';
import { 
  Target, 
  Camera, 
  MessageCircle, 
  Phone, 
  Calendar,
  UserCheck,
  Heart,
  CheckCircle,
  XCircle,
  AlertCircle,
  PhoneOff,
  Clock,
  TrendingUp
} from 'lucide-react';
import { useMemo } from 'react';

interface AnalysisProps {
  filters: FilterState;
}

export const Analysis = ({ filters }: AnalysisProps) => {
  const { leads, scouters, projects, isLoading: dataLoading, error: dataError, syncData, isConfigured, lastSync } = useLeadsData();
  
  // Filter leads based on current filters
  const filteredLeads = useMemo(() => {
    const selectedScouterNames = filters.scouterIds.length
      ? scouters.filter(s => filters.scouterIds.includes(s.id)).map(s => s.name)
      : [];
    const selectedProjectNames = filters.projectIds.length
      ? projects.filter(p => filters.projectIds.includes(p.id)).map(p => p.name)
      : [];

    return leads.filter(lead => {
      const leadDate = new Date(lead.created_at);
      const dateInRange = leadDate >= filters.dateRange.from && leadDate <= filters.dateRange.to;
      
      const scouterMatch = filters.scouterIds.length === 0 || 
        (lead.scouter_id && selectedScouterNames.includes(lead.scouter_id));
      
      const projectMatch = filters.projectIds.length === 0 || 
        (lead.project_id && selectedProjectNames.includes(lead.project_id));

      return dateInRange && scouterMatch && projectMatch;
    });
  }, [leads, filters, scouters, projects]);

  // Calculate KPIs
  const kpis = useMemo((): KPIData => {
    const uniqueLeads = Array.from(new Map(filteredLeads.map(l => [l.id, l])).values());
    const total = uniqueLeads.length;
    if (total === 0) {
      return {
        total_fichas: 0,
        pct_com_foto: 0,
        pct_confirmadas: 0,
        pct_conseguiu_contato: 0,
        pct_agendadas: 0,
        pct_compareceu: 0,
        pct_interesse: 0,
        pct_concluido_pos: 0,
        pct_concluido_neg: 0,
        pct_sem_interesse_def: 0,
        pct_sem_contato: 0,
        pct_sem_interesse_momento: 0,
        iqs_medio: 0,
      };
    }

    return {
      total_fichas: total,
      pct_com_foto: (uniqueLeads.filter(l => l.has_photo).length / total) * 100,
      pct_confirmadas: (uniqueLeads.filter(l => l.confirmed_whatsapp).length / total) * 100,
      pct_conseguiu_contato: (uniqueLeads.filter(l => l.contacted).length / total) * 100,
      pct_agendadas: (uniqueLeads.filter(l => l.stage === 'agendado').length / total) * 100,
      pct_compareceu: (uniqueLeads.filter(l => l.presenca_confirmada).length / total) * 100,
      pct_interesse: (uniqueLeads.filter(l => l.stage === 'interesse').length / total) * 100,
      pct_concluido_pos: (uniqueLeads.filter(l => l.stage === 'concluido_pos').length / total) * 100,
      pct_concluido_neg: (uniqueLeads.filter(l => l.stage === 'concluido_neg').length / total) * 100,
      pct_sem_interesse_def: (uniqueLeads.filter(l => l.stage === 'sem_interesse_def').length / total) * 100,
      pct_sem_contato: (uniqueLeads.filter(l => l.stage === 'sem_contato').length / total) * 100,
      pct_sem_interesse_momento: (uniqueLeads.filter(l => l.stage === 'sem_interesse_momento').length / total) * 100,
      iqs_medio: uniqueLeads.reduce((sum, l) => sum + (l.iqs || 0), 0) / total,
    };
  }, [filteredLeads]);

  const kpiCards = [
    {
      label: 'Total de Fichas',
      value: kpis.total_fichas.toString(),
      icon: Target,
      color: 'text-primary',
      bgColor: 'bg-primary-light',
    },
    {
      label: '% com Foto',
      value: `${kpis.pct_com_foto.toFixed(1)}%`,
      icon: Camera,
      color: 'text-analytics-blue',
      bgColor: 'bg-primary-light',
    },
    {
      label: '% Confirmadas',
      value: `${kpis.pct_confirmadas.toFixed(1)}%`,
      icon: MessageCircle,
      color: 'text-analytics-green',
      bgColor: 'bg-success-light',
    },
    {
      label: '% Conseguiu Contato',
      value: `${kpis.pct_conseguiu_contato.toFixed(1)}%`,
      icon: Phone,
      color: 'text-analytics-orange',
      bgColor: 'bg-warning-light',
    },
    {
      label: '% Agendadas',
      value: `${kpis.pct_agendadas.toFixed(1)}%`,
      icon: Calendar,
      color: 'text-analytics-purple',
      bgColor: 'bg-primary-light',
    },
    {
      label: '% Compareceu',
      value: `${kpis.pct_compareceu.toFixed(1)}%`,
      icon: UserCheck,
      color: 'text-success',
      bgColor: 'bg-success-light',
    },
    {
      label: '% Interesse',
      value: `${kpis.pct_interesse.toFixed(1)}%`,
      icon: Heart,
      color: 'text-analytics-pink',
      bgColor: 'bg-primary-light',
    },
    {
      label: '% Concluído Positivo',
      value: `${kpis.pct_concluido_pos.toFixed(1)}%`,
      icon: CheckCircle,
      color: 'text-success',
      bgColor: 'bg-success-light',
    },
    {
      label: '% Concluído Negativo',
      value: `${kpis.pct_concluido_neg.toFixed(1)}%`,
      icon: XCircle,
      color: 'text-danger',
      bgColor: 'bg-danger-light',
    },
    {
      label: '% Sem Interesse Definitivo',
      value: `${kpis.pct_sem_interesse_def.toFixed(1)}%`,
      icon: AlertCircle,
      color: 'text-danger',
      bgColor: 'bg-danger-light',
    },
    {
      label: '% Sem Contato',
      value: `${kpis.pct_sem_contato.toFixed(1)}%`,
      icon: PhoneOff,
      color: 'text-muted-foreground',
      bgColor: 'bg-muted',
    },
    {
      label: '% Sem Interesse Momento',
      value: `${kpis.pct_sem_interesse_momento.toFixed(1)}%`,
      icon: Clock,
      color: 'text-warning',
      bgColor: 'bg-warning-light',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Data Sync Status */}
      <DataSyncStatus
        isConfigured={isConfigured}
        isLoading={dataLoading}
        error={dataError}
        lastSync={lastSync}
        onSync={syncData}
      />
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Análise de Performance</h1>
          <p className="text-muted-foreground">
            Dashboard com métricas e indicadores de qualidade dos scouters
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="text-sm">
            {filteredLeads.length} fichas encontradas
          </Badge>
          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
            <TrendingUp className="h-4 w-4" />
            <span>IQS Médio: {kpis.iqs_medio.toFixed(1)}</span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {kpiCards.map((kpi, index) => (
          <Card key={index} className="hover:shadow-md-primary transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground font-medium">
                    {kpi.label}
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {kpi.value}
                  </p>
                </div>
                <div className={`p-3 rounded-full ${kpi.bgColor}`}>
                  <kpi.icon className={`h-6 w-6 ${kpi.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-md-primary">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <span>Resumo de Performance</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-success-light rounded-lg">
                <p className="text-2xl font-bold text-success">
                  {(kpis.pct_concluido_pos + kpis.pct_compareceu).toFixed(1)}%
                </p>
                <p className="text-sm text-success-foreground">Taxa de Sucesso</p>
              </div>
              <div className="text-center p-4 bg-primary-light rounded-lg">
                <p className="text-2xl font-bold text-primary">
                  {kpis.iqs_medio.toFixed(1)}
                </p>
                <p className="text-sm text-foreground">IQS Médio</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md-primary">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertCircle className="h-5 w-5 text-warning" />
              <span>Pontos de Atenção</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {kpis.pct_sem_contato > 20 && (
              <div className="flex items-center space-x-2 text-warning">
                <PhoneOff className="h-4 w-4" />
                <span className="text-sm">
                  Alto índice de fichas sem contato ({kpis.pct_sem_contato.toFixed(1)}%)
                </span>
              </div>
            )}
            {kpis.pct_com_foto < 70 && (
              <div className="flex items-center space-x-2 text-warning">
                <Camera className="h-4 w-4" />
                <span className="text-sm">
                  Baixo índice de fichas com foto ({kpis.pct_com_foto.toFixed(1)}%)
                </span>
              </div>
            )}
            {kpis.pct_confirmadas < 80 && (
              <div className="flex items-center space-x-2 text-warning">
                <MessageCircle className="h-4 w-4" />
                <span className="text-sm">
                  Baixo índice de confirmação WhatsApp ({kpis.pct_confirmadas.toFixed(1)}%)
                </span>
              </div>
            )}
            {kpis.pct_sem_contato <= 20 && kpis.pct_com_foto >= 70 && kpis.pct_confirmadas >= 80 && (
              <div className="flex items-center space-x-2 text-success">
                <CheckCircle className="h-4 w-4" />
                <span className="text-sm">Todos os indicadores estão dentro do esperado</span>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Leads Table Preview */}
      <Card className="shadow-md-primary">
        <CardHeader>
          <CardTitle>Fichas Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left p-2">Data</th>
                  <th className="text-left p-2">Scouter</th>
                  <th className="text-left p-2">Modelo</th>
                  <th className="text-left p-2">Projeto</th>
                  <th className="text-left p-2">Estágio</th>
                  <th className="text-left p-2">IQS</th>
                  <th className="text-left p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredLeads.slice(0, 10).map((lead) => (
                  <tr key={lead.id} className="border-b border-border hover:bg-muted/50">
                    <td className="p-2">
                      {new Date(lead.created_at).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="p-2">
                      {scouters.find(s => s.id === lead.scouter_id)?.name || lead.scouter_id || 'N/A'}
                    </td>
                    <td className="p-2">{lead.modelo}</td>
                    <td className="p-2">
                      {projects.find(p => p.id === lead.project_id)?.name || lead.project_id || 'N/A'}
                    </td>
                    <td className="p-2">
                      <Badge variant="outline" className="text-xs">
                        {lead.stage.replace('_', ' ')}
                      </Badge>
                    </td>
                    <td className="p-2">
                      <span className="font-medium">
                        {lead.iqs?.toFixed(1) || 'N/A'}
                      </span>
                    </td>
                    <td className="p-2">
                      <div className="flex space-x-1">
                        {lead.has_photo && (
                          <Camera className="h-3 w-3 text-success" />
                        )}
                        {lead.confirmed_whatsapp && (
                          <MessageCircle className="h-3 w-3 text-success" />
                        )}
                        {lead.contacted && (
                          <Phone className="h-3 w-3 text-success" />
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};