import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FilterState } from '@/types/database';
import { useLeadsData } from '@/hooks/useLeadsData';
import { DataSyncStatus } from '@/components/common/DataSyncStatus';
import { 
  CreditCard, 
  DollarSign, 
  Users, 
  FileText,
  Download,
  CheckCircle,
  Clock,
  TrendingUp,
  Calculator
} from 'lucide-react';
import { useMemo } from 'react';

interface PaymentsProps {
  filters: FilterState;
}

export const Payments = ({ filters }: PaymentsProps) => {
  const { leads, scouters, isLoading: dataLoading, error: dataError, syncData, isConfigured, lastSync } = useLeadsData();
  // Filter leads based on current filters
  const filteredLeads = useMemo(() => {
    return leads.filter(lead => {
      const leadDate = new Date(lead.created_at);
      const dateInRange = leadDate >= filters.dateRange.from && leadDate <= filters.dateRange.to;
      
      const scouterMatch = filters.scouterIds.length === 0 || 
        (lead.scouter_id && filters.scouterIds.includes(lead.scouter_id));
      
      const projectMatch = filters.projectIds.length === 0 || 
        (lead.project_id && filters.projectIds.includes(lead.project_id));

      return dateInRange && scouterMatch && projectMatch;
    });
  }, [leads, filters]);

  // Mock payment calculations
  const paymentData = useMemo(() => {
    const scouterPayments = new Map<string, {
      scouter: any;
      fichasElegiveis: number;
      valorFichas: number;
      ajudaCusto: number;
      total: number;
      status: 'a_pagar' | 'pago';
    }>();

    // Default multipliers
    const multipliers = {
      'concluido_pos': 1.00,
      'compareceu': 0.90,
      'agendado': 0.75,
      'interesse': 0.50,
      'concluido_neg': 0.25,
      'novo': 0.00,
      'confirmado': 0.00,
      'sem_interesse_def': 0.00,
      'sem_contato': 0.00,
      'sem_interesse_momento': 0.00,
    };

    filteredLeads.forEach(lead => {
      if (!lead.scouter_id) return;

      const scouter = scouters.find(s => s.id === lead.scouter_id);
      if (!scouter) return;

      // Check eligibility (has photo and confirmed whatsapp by default)
      const isEligible = lead.has_photo && lead.confirmed_whatsapp;
      if (!isEligible) return;

      const multiplier = multipliers[lead.stage as keyof typeof multipliers] || 0;
      const valorBase = 25; // R$ 25 per lead base value
      const valorFicha = valorBase * multiplier;

      if (!scouterPayments.has(lead.scouter_id)) {
        scouterPayments.set(lead.scouter_id, {
          scouter,
          fichasElegiveis: 0,
          valorFichas: 0,
          ajudaCusto: 0,
          total: 0,
          status: Math.random() > 0.7 ? 'pago' : 'a_pagar',
        });
      }

      const payment = scouterPayments.get(lead.scouter_id)!;
      payment.fichasElegiveis++;
      payment.valorFichas += valorFicha;
    });

    // Add help cost (ajuda de custo) based on minimum requirements
    scouterPayments.forEach((payment) => {
      // Mock condition: if has more than 10 eligible leads, gets help cost
      if (payment.fichasElegiveis >= 10) {
        payment.ajudaCusto = 200; // R$ 200 help cost
      }
      payment.total = payment.valorFichas + payment.ajudaCusto;
    });

    return Array.from(scouterPayments.values());
  }, [filteredLeads]);

  const totals = useMemo(() => {
    return paymentData.reduce(
      (acc, payment) => {
        acc.fichasElegiveis += payment.fichasElegiveis;
        acc.valorTotal += payment.total;
        acc.valorFichas += payment.valorFichas;
        acc.ajudaCusto += payment.ajudaCusto;
        if (payment.status === 'pago') {
          acc.valorPago += payment.total;
        } else {
          acc.valorAPagar += payment.total;
        }
        return acc;
      },
      {
        fichasElegiveis: 0,
        valorTotal: 0,
        valorFichas: 0,
        ajudaCusto: 0,
        valorPago: 0,
        valorAPagar: 0,
      }
    );
  }, [paymentData]);

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('pt-BR', { 
      style: 'currency', 
      currency: 'BRL' 
    }).format(value);

  return (
    <div className="space-y-6">
      {/* Data Sync Status */}
      <DataSyncStatus
        isConfigured={isConfigured}
        isLoading={dataLoading}
        error={dataError}
        lastSync={lastSync}
        onSync={syncData}
      />
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Controle de Pagamentos</h1>
          <p className="text-muted-foreground">
            Gestão de pagamentos por fichas e ajuda de custo
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
          <Button className="bg-gradient-primary">
            <FileText className="mr-2 h-4 w-4" />
            Gerar Lote
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="shadow-md-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">
                  Total a Pagar
                </p>
                <p className="text-2xl font-bold text-warning">
                  {formatCurrency(totals.valorAPagar)}
                </p>
              </div>
              <div className="p-3 rounded-full bg-warning-light">
                <Clock className="h-6 w-6 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">
                  Total Pago
                </p>
                <p className="text-2xl font-bold text-success">
                  {formatCurrency(totals.valorPago)}
                </p>
              </div>
              <div className="p-3 rounded-full bg-success-light">
                <CheckCircle className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">
                  Fichas Elegíveis
                </p>
                <p className="text-2xl font-bold text-primary">
                  {totals.fichasElegiveis}
                </p>
              </div>
              <div className="p-3 rounded-full bg-primary-light">
                <FileText className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">
                  Valor Total
                </p>
                <p className="text-2xl font-bold text-foreground">
                  {formatCurrency(totals.valorTotal)}
                </p>
              </div>
              <div className="p-3 rounded-full bg-muted">
                <DollarSign className="h-6 w-6 text-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-md-primary">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calculator className="h-5 w-5 text-primary" />
              <span>Resumo Financeiro</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-border">
              <span className="text-muted-foreground">Valor por Fichas</span>
              <span className="font-medium">{formatCurrency(totals.valorFichas)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border">
              <span className="text-muted-foreground">Ajuda de Custo</span>
              <span className="font-medium">{formatCurrency(totals.ajudaCusto)}</span>
            </div>
            <div className="flex justify-between items-center py-2 font-bold text-lg">
              <span>Total Geral</span>
              <span className="text-primary">{formatCurrency(totals.valorTotal)}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md-primary">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-analytics-green" />
              <span>Estatísticas</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-primary-light rounded-lg">
                <p className="text-lg font-bold text-primary">
                  {paymentData.length}
                </p>
                <p className="text-sm text-foreground">Scouters Ativos</p>
              </div>
              <div className="text-center p-3 bg-success-light rounded-lg">
                <p className="text-lg font-bold text-success">
                  {formatCurrency(totals.valorFichas / totals.fichasElegiveis || 0)}
                </p>
                <p className="text-sm text-success-foreground">Valor Médio/Ficha</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Scouter Payments Table */}
      <Card className="shadow-md-primary">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="h-5 w-5 text-primary" />
            <span>Pagamentos por Scouter</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left p-3">Scouter</th>
                  <th className="text-left p-3">Fichas Elegíveis</th>
                  <th className="text-left p-3">Valor Fichas</th>
                  <th className="text-left p-3">Ajuda de Custo</th>
                  <th className="text-left p-3">Total</th>
                  <th className="text-left p-3">Status</th>
                  <th className="text-left p-3">Ações</th>
                </tr>
              </thead>
              <tbody>
                {paymentData.map((payment) => (
                  <tr key={payment.scouter.id} className="border-b border-border hover:bg-muted/50">
                    <td className="p-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold">
                          {payment.scouter.name.split(' ').map((n: string) => n[0]).join('')}
                        </div>
                        <span className="font-medium">{payment.scouter.name}</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <Badge variant="outline">
                        {payment.fichasElegiveis}
                      </Badge>
                    </td>
                    <td className="p-3 font-medium">
                      {formatCurrency(payment.valorFichas)}
                    </td>
                    <td className="p-3 font-medium">
                      {formatCurrency(payment.ajudaCusto)}
                    </td>
                    <td className="p-3 font-bold text-primary">
                      {formatCurrency(payment.total)}
                    </td>
                    <td className="p-3">
                      <Badge 
                        variant={payment.status === 'pago' ? 'default' : 'secondary'}
                        className={payment.status === 'pago' ? 'bg-success text-success-foreground' : 'bg-warning text-warning-foreground'}
                      >
                        {payment.status === 'pago' ? 'Pago' : 'A Pagar'}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <div className="flex space-x-2">
                        {payment.status === 'a_pagar' ? (
                          <Button size="sm" variant="outline">
                            <CreditCard className="mr-1 h-3 w-3" />
                            Pagar
                          </Button>
                        ) : (
                          <Button size="sm" variant="ghost">
                            <FileText className="mr-1 h-3 w-3" />
                            Recibo
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};