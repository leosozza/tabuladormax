import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CSVImport } from '@/components/import/CSVImport';
import { GoogleSheetsConfig } from '@/components/sheets/GoogleSheetsConfig';
import { GoogleSheetsSync } from '@/components/sheets/GoogleSheetsSync';
import { useLeadsData } from '@/hooks/useLeadsData';
import { 
  Settings, 
  Weight, 
  DollarSign, 
  Users, 
  Shield,
  Save,
  RotateCcw,
  AlertTriangle,
  CheckCircle,
  FileSpreadsheet
} from 'lucide-react';

export const Configuration = () => {
  const { scouters } = useLeadsData();
  const [weights, setWeights] = useState({
    peso_foto: 20,
    peso_confirmada: 20,
    peso_contato: 10,
    peso_interesse: 10,
    peso_agendado: 15,
    peso_compareceu: 20,
    peso_concluido_pos: 25,
    peso_concluido_neg: -10,
    peso_sem_interesse_def: -20,
    peso_sem_contato: -15,
    peso_sem_interesse_momento: -5,
  });

  const [multipliers, setMultipliers] = useState({
    'concluido_pos': 1.00,
    'compareceu': 0.90,
    'agendado': 0.75,
    'interesse': 0.50,
    'concluido_neg': 0.25,
    'novo': 0.00,
    'confirmado': 0.00,
    'sem_interesse_def': 0.00,
    'sem_contato': 0.00,
    'sem_interesse_momento': 0.00,
  });

  const [eligibilityRules, setEligibilityRules] = useState({
    exigir_foto: true,
    exigir_confirmacao: true,
    exigir_contato: false,
  });

  const [classifications, setClassifications] = useState([
    {
      id: '1',
      scouter_id: '1',
      valor_por_ficha: 25.00,
      ajuda_custo: 200.00,
      meta_fichas: 20,
      pct_min_interesse: 15.0,
      pct_max_sem_contato: 30.0,
      pct_min_fotos: 70.0,
      pct_min_agendadas: 10.0,
      pct_min_compareceu: 5.0,
      nivel: 'S2' as const,
    },
    {
      id: '2',
      scouter_id: '2',
      valor_por_ficha: 30.00,
      ajuda_custo: 250.00,
      meta_fichas: 25,
      pct_min_interesse: 20.0,
      pct_max_sem_contato: 25.0,
      pct_min_fotos: 80.0,
      pct_min_agendadas: 15.0,
      pct_min_compareceu: 8.0,
      nivel: 'S3' as const,
    },
  ]);

  const handleWeightChange = (key: string, value: number) => {
    setWeights(prev => ({ ...prev, [key]: value }));
  };

  const handleMultiplierChange = (stage: string, value: number) => {
    setMultipliers(prev => ({ ...prev, [stage]: value }));
  };

  const handleEligibilityChange = (key: string, value: boolean) => {
    setEligibilityRules(prev => ({ ...prev, [key]: value }));
  };

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('pt-BR', { 
      style: 'currency', 
      currency: 'BRL' 
    }).format(value);

  const getLevelBadge = (nivel?: string) => {
    switch (nivel) {
      case 'S3':
        return <Badge className="bg-success text-success-foreground">Sênior</Badge>;
      case 'S2':
        return <Badge className="bg-primary text-primary-foreground">Pleno</Badge>;
      case 'S1':
        return <Badge variant="secondary">Júnior</Badge>;
      default:
        return <Badge variant="outline">N/A</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Configurações do Sistema</h1>
          <p className="text-muted-foreground">
            Gerenciar pesos, regras de pagamento e classificações
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <RotateCcw className="mr-2 h-4 w-4" />
            Restaurar Padrões
          </Button>
          <Button className="bg-gradient-primary">
            <Save className="mr-2 h-4 w-4" />
            Salvar Alterações
          </Button>
        </div>
      </div>

      <Tabs defaultValue="weights" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="weights" className="flex items-center space-x-2">
            <Weight className="h-4 w-4" />
            <span>Pesos IQS</span>
          </TabsTrigger>
          <TabsTrigger value="multipliers" className="flex items-center space-x-2">
            <DollarSign className="h-4 w-4" />
            <span>Multiplicadores</span>
          </TabsTrigger>
          <TabsTrigger value="eligibility" className="flex items-center space-x-2">
            <Shield className="h-4 w-4" />
            <span>Elegibilidade</span>
          </TabsTrigger>
          <TabsTrigger value="classifications" className="flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span>Classificações</span>
          </TabsTrigger>
          <TabsTrigger value="sheets" className="flex items-center space-x-2">
            <FileSpreadsheet className="h-4 w-4" />
            <span>Google Sheets</span>
          </TabsTrigger>
          <TabsTrigger value="import" className="flex items-center space-x-2">
            <FileSpreadsheet className="h-4 w-4" />
            <span>Importar CSV</span>
          </TabsTrigger>
        </TabsList>

        {/* Indicator Weights */}
        <TabsContent value="weights">
          <Card className="shadow-md-primary">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Weight className="h-5 w-5 text-primary" />
                <span>Pesos dos Indicadores (IQS)</span>
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure os pesos utilizados no cálculo do Índice de Qualidade do Scouter (IQS)
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Object.entries(weights).map(([key, value]) => {
                  const labels: Record<string, string> = {
                    peso_foto: 'Foto',
                    peso_confirmada: 'Ficha Confirmada',
                    peso_contato: 'Conseguiu Contato',
                    peso_interesse: 'Com Interesse',
                    peso_agendado: 'Agendado',
                    peso_compareceu: 'Compareceu',
                    peso_concluido_pos: 'Concluído Positivo',
                    peso_concluido_neg: 'Concluído Negativo',
                    peso_sem_interesse_def: 'Sem Interesse Definitivo',
                    peso_sem_contato: 'Sem Contato',
                    peso_sem_interesse_momento: 'Sem Interesse no Momento',
                  };

                  return (
                    <div key={key} className="space-y-2">
                      <Label htmlFor={key} className="text-sm font-medium">
                        {labels[key]}
                      </Label>
                      <div className="flex items-center space-x-2">
                        <Input
                          id={key}
                          type="number"
                          min="-50"
                          max="50"
                          value={value}
                          onChange={(e) => handleWeightChange(key, parseInt(e.target.value) || 0)}
                          className="w-20"
                        />
                        <span className="text-sm text-muted-foreground">pts</span>
                        {value < 0 && (
                          <AlertTriangle className="h-4 w-4 text-warning" />
                        )}
                        {value > 0 && (
                          <CheckCircle className="h-4 w-4 text-success" />
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-6 p-4 bg-muted rounded-lg">
                <h4 className="font-medium mb-2">Resumo dos Pesos</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Pesos Positivos:</span>
                    <span className="ml-2 font-medium text-success">
                      {Object.values(weights).filter(w => w > 0).reduce((sum, w) => sum + w, 0)} pts
                    </span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Pesos Negativos:</span>
                    <span className="ml-2 font-medium text-danger">
                      {Object.values(weights).filter(w => w < 0).reduce((sum, w) => sum + w, 0)} pts
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Multipliers */}
        <TabsContent value="multipliers">
          <Card className="shadow-md-primary">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="h-5 w-5 text-primary" />
                <span>Multiplicadores de Pagamento</span>
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure os multiplicadores aplicados ao valor base por estágio da ficha
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(multipliers).map(([stage, value]) => {
                  const labels: Record<string, string> = {
                    'concluido_pos': 'Concluído Positivo',
                    'compareceu': 'Compareceu',
                    'agendado': 'Agendado',
                    'interesse': 'Com Interesse',
                    'concluido_neg': 'Concluído Negativo',
                    'novo': 'Novo',
                    'confirmado': 'Confirmado',
                    'sem_interesse_def': 'Sem Interesse Definitivo',
                    'sem_contato': 'Sem Contato',
                    'sem_interesse_momento': 'Sem Interesse no Momento',
                  };

                  const getMultiplierColor = (mult: number) => {
                    if (mult >= 1.0) return 'text-success';
                    if (mult >= 0.5) return 'text-warning';
                    if (mult > 0) return 'text-muted-foreground';
                    return 'text-danger';
                  };

                  return (
                    <div key={stage} className="flex items-center justify-between p-3 border border-border rounded-lg">
                      <div className="flex-1">
                        <Label className="font-medium">{labels[stage]}</Label>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <Input
                            type="number"
                            min="0"
                            max="2"
                            step="0.05"
                            value={value}
                            onChange={(e) => handleMultiplierChange(stage, parseFloat(e.target.value) || 0)}
                            className="w-20"
                          />
                          <span className="text-sm text-muted-foreground">×</span>
                        </div>
                        <div className="text-right min-w-20">
                          <span className={`font-medium ${getMultiplierColor(value)}`}>
                            {(value * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-6 p-4 bg-primary-light rounded-lg">
                <h4 className="font-medium mb-2">Exemplo de Cálculo</h4>
                <p className="text-sm text-muted-foreground">
                  Valor base: R$ 25,00 × Multiplicador = Valor final da ficha
                </p>
                <div className="mt-2 text-sm">
                  <span className="text-muted-foreground">Ex: Ficha "Agendado":</span>
                  <span className="ml-2 font-medium">R$ 25,00 × {multipliers.agendado} = {formatCurrency(25 * multipliers.agendado)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Eligibility Rules */}
        <TabsContent value="eligibility">
          <Card className="shadow-md-primary">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-primary" />
                <span>Regras de Elegibilidade</span>
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure os requisitos mínimos para que uma ficha seja elegível para pagamento
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="space-y-1">
                    <Label className="font-medium">Exigir Foto</Label>
                    <p className="text-sm text-muted-foreground">
                      A ficha deve ter foto para ser elegível ao pagamento
                    </p>
                  </div>
                  <Switch
                    checked={eligibilityRules.exigir_foto}
                    onCheckedChange={(checked) => handleEligibilityChange('exigir_foto', checked)}
                  />
                </div>

                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="space-y-1">
                    <Label className="font-medium">Exigir Confirmação WhatsApp</Label>
                    <p className="text-sm text-muted-foreground">
                      A ficha deve ter confirmação no WhatsApp para pagamento
                    </p>
                  </div>
                  <Switch
                    checked={eligibilityRules.exigir_confirmacao}
                    onCheckedChange={(checked) => handleEligibilityChange('exigir_confirmacao', checked)}
                  />
                </div>

                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="space-y-1">
                    <Label className="font-medium">Exigir Contato Concluído</Label>
                    <p className="text-sm text-muted-foreground">
                      A ficha deve ter contato concluído para ser elegível
                    </p>
                  </div>
                  <Switch
                    checked={eligibilityRules.exigir_contato}
                    onCheckedChange={(checked) => handleEligibilityChange('exigir_contato', checked)}
                  />
                </div>
              </div>

              <div className="p-4 bg-warning-light rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  <span className="font-medium text-warning-foreground">Atenção</span>
                </div>
                <p className="text-sm text-warning-foreground">
                  Alterações nas regras de elegibilidade afetam apenas novos lotes de pagamento. 
                  Lotes já gerados mantêm as regras originais.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Scouter Classifications */}
        <TabsContent value="classifications">
          <Card className="shadow-md-primary">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-primary" />
                <span>Classificações de Scouters</span>
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure valores, metas e mínimos de qualidade por scouter
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {classifications.map((classification) => {
                  const scouter = scouters.find(s => s.id === classification.scouter_id);
                  if (!scouter) return null;

                  return (
                    <div key={classification.id} className="p-4 border border-border rounded-lg space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                            <span className="text-sm text-white font-bold">
                              {scouter.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div>
                            <h4 className="font-medium">{scouter.name}</h4>
                            <p className="text-sm text-muted-foreground">{scouter.phone}</p>
                          </div>
                        </div>
                        {getLevelBadge(classification.nivel)}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Valor por Ficha</Label>
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            value={classification.valor_por_ficha}
                            onChange={(e) => {
                              const newClassifications = classifications.map(c =>
                                c.id === classification.id
                                  ? { ...c, valor_por_ficha: parseFloat(e.target.value) || 0 }
                                  : c
                              );
                              setClassifications(newClassifications);
                            }}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Ajuda de Custo</Label>
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            value={classification.ajuda_custo}
                            onChange={(e) => {
                              const newClassifications = classifications.map(c =>
                                c.id === classification.id
                                  ? { ...c, ajuda_custo: parseFloat(e.target.value) || 0 }
                                  : c
                              );
                              setClassifications(newClassifications);
                            }}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Meta de Fichas</Label>
                          <Input
                            type="number"
                            min="0"
                            value={classification.meta_fichas}
                            onChange={(e) => {
                              const newClassifications = classifications.map(c =>
                                c.id === classification.id
                                  ? { ...c, meta_fichas: parseInt(e.target.value) || 0 }
                                  : c
                              );
                              setClassifications(newClassifications);
                            }}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                        <div className="space-y-2">
                          <Label className="text-xs">% Min Interesse</Label>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            value={classification.pct_min_interesse}
                            className="text-sm"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-xs">% Max Sem Contato</Label>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            value={classification.pct_max_sem_contato}
                            className="text-sm"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-xs">% Min Fotos</Label>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            value={classification.pct_min_fotos}
                            className="text-sm"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-xs">% Min Agendadas</Label>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            value={classification.pct_min_agendadas}
                            className="text-sm"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-xs">% Min Compareceu</Label>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            value={classification.pct_min_compareceu}
                            className="text-sm"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

          <TabsContent value="sheets" className="space-y-6">
            <GoogleSheetsConfig />
            <GoogleSheetsSync />
          </TabsContent>

          <TabsContent value="import">
            <CSVImport />
          </TabsContent>
      </Tabs>
    </div>
  );
};