import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FilterState } from '@/types/database';
import { useLeadsData } from '@/hooks/useLeadsData';
import { DataSyncStatus } from '@/components/common/DataSyncStatus';
import { MapboxMap } from '@/components/MapboxMap';
import { 
  Map as MapIcon, 
  Layers, 
  MapPin, 
  Navigation,
  Zap,
  Users,
  Target,
  Info
} from 'lucide-react';
import { useMemo } from 'react';

interface MapViewProps {
  filters: FilterState;
}

export const MapView = ({ filters }: MapViewProps) => {
  const { leads, scouters, projects, isLoading: dataLoading, error: dataError, syncData, isConfigured, lastSync } = useLeadsData();
  // Filter leads based on current filters
  const filteredLeads = useMemo(() => {
    const selectedScouterNames = filters.scouterIds.length
      ? scouters.filter(s => filters.scouterIds.includes(s.id)).map(s => s.name)
      : [];
    const selectedProjectNames = filters.projectIds.length
      ? projects.filter(p => filters.projectIds.includes(p.id)).map(p => p.name)
      : [];

    return leads.filter(lead => {
      const leadDate = new Date(lead.created_at);
      const dateInRange = leadDate >= filters.dateRange.from && leadDate <= filters.dateRange.to;
      
      const scouterMatch = filters.scouterIds.length === 0 || 
        (lead.scouter_id && selectedScouterNames.includes(lead.scouter_id));
      
      const projectMatch = filters.projectIds.length === 0 || 
        (lead.project_id && selectedProjectNames.includes(lead.project_id));

      return dateInRange && scouterMatch && projectMatch;
    });
  }, [leads, filters, scouters, projects]);

  // Group leads by region for heatmap simulation
  const regionData = useMemo(() => {
    const regions = new Map<string, { count: number; lat: number; lng: number; intensity: 'low' | 'medium' | 'high' }>();
    
    filteredLeads.forEach(lead => {
      if (!lead.lat || !lead.lng) return;
      
      // Create grid-based regions (simplified H3 simulation)
      const regionKey = `${Math.floor(lead.lat * 100)}_${Math.floor(lead.lng * 100)}`;
      
      if (!regions.has(regionKey)) {
        regions.set(regionKey, {
          count: 0,
          lat: lead.lat,
          lng: lead.lng,
          intensity: 'low'
        });
      }
      
      const region = regions.get(regionKey)!;
      region.count++;
      
      // Determine intensity based on count
      if (region.count >= 10) region.intensity = 'high';
      else if (region.count >= 5) region.intensity = 'medium';
      else region.intensity = 'low';
    });
    
    return Array.from(regions.values());
  }, [filteredLeads]);

  // Scouter tracking data (mock)
  const scouterTracking = useMemo(() => {
    return scouters
      .filter(s => s.active)
      .filter(s => filters.scouterIds.length === 0 || filters.scouterIds.includes(s.id))
      .map(scouter => {
        const scouterLeads = filteredLeads.filter(l => l.scouter_id === scouter.id);
        const avgLat = scouterLeads.reduce((sum, l) => sum + (l.lat || 0), 0) / scouterLeads.length || -23.5505;
        const avgLng = scouterLeads.reduce((sum, l) => sum + (l.lng || 0), 0) / scouterLeads.length || -46.6333;
        
        return {
          scouter,
          currentPosition: { lat: avgLat, lng: avgLng },
          leadsInArea: scouterLeads.length,
          lastUpdate: new Date(),
        };
      });
  }, [filteredLeads, filters.scouterIds, scouters]);

  const getIntensityColor = (intensity: 'low' | 'medium' | 'high') => {
    switch (intensity) {
      case 'high': return 'bg-map-heat-high border-map-heat-high';
      case 'medium': return 'bg-map-heat-medium border-map-heat-medium';
      default: return 'bg-map-heat-low border-map-heat-low';
    }
  };

  return (
    <div className="space-y-6">
      {/* Data Sync Status */}
      <DataSyncStatus
        isConfigured={isConfigured}
        isLoading={dataLoading}
        error={dataError}
        lastSync={lastSync}
        onSync={syncData}
      />
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Análise Geográfica</h1>
          <p className="text-muted-foreground">
            Heatmap de densidade e rastreamento de scouters
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Layers className="mr-2 h-4 w-4" />
            Camadas
          </Button>
          <Button variant="outline">
            <Navigation className="mr-2 h-4 w-4" />
            Centrar
          </Button>
        </div>
      </div>

      {/* Map Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="shadow-md-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">
                  Fichas Mapeadas
                </p>
                <p className="text-2xl font-bold text-primary">
                  {filteredLeads.length}
                </p>
              </div>
              <div className="p-3 rounded-full bg-primary-light">
                <MapPin className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">
                  Regiões Ativas
                </p>
                <p className="text-2xl font-bold text-analytics-green">
                  {regionData.length}
                </p>
              </div>
              <div className="p-3 rounded-full bg-success-light">
                <Target className="h-6 w-6 text-analytics-green" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">
                  Scouters Ativos
                </p>
                <p className="text-2xl font-bold text-analytics-orange">
                  {scouterTracking.length}
                </p>
              </div>
              <div className="p-3 rounded-full bg-warning-light">
                <Users className="h-6 w-6 text-analytics-orange" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md-primary">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground font-medium">
                  Densidade Máxima
                </p>
                <p className="text-2xl font-bold text-map-heat-high">
                  {Math.max(...regionData.map(r => r.count), 0)}
                </p>
              </div>
              <div className="p-3 rounded-full bg-danger-light">
                <Zap className="h-6 w-6 text-map-heat-high" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Map Area */}
        <Card className="lg:col-span-2 shadow-md-primary">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MapIcon className="h-5 w-5 text-primary" />
              <span>Mapa Interativo - Localização das Fichas</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <MapboxMap 
              leads={filteredLeads} 
              onLeadClick={(lead) => {
                console.log('Lead clicado:', lead);
              }} 
            />
          </CardContent>
        </Card>

        {/* Side Panel */}
        <div className="space-y-6">
          {/* Scouter Tracking */}
          <Card className="shadow-md-primary">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-analytics-orange" />
                <span>Scouters em Campo</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {scouterTracking.slice(0, 5).map((tracking) => (
                <div key={tracking.scouter.id} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                      <span className="text-xs text-white font-bold">
                        {tracking.scouter.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <span className="text-sm font-medium">{tracking.scouter.name}</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {tracking.leadsInArea} fichas
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Density Analysis */}
          <Card className="shadow-md-primary">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5 text-analytics-green" />
                <span>Análise de Densidade</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Regiões de Alta Densidade:</span>
                  <span className="font-medium">
                    {regionData.filter(r => r.intensity === 'high').length}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Regiões de Média Densidade:</span>
                  <span className="font-medium">
                    {regionData.filter(r => r.intensity === 'medium').length}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Regiões de Baixa Densidade:</span>
                  <span className="font-medium">
                    {regionData.filter(r => r.intensity === 'low').length}
                  </span>
                </div>
              </div>
              
              <div className="pt-3 border-t border-border">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Info className="h-4 w-4" />
                  <span>Atualizado em tempo real</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};