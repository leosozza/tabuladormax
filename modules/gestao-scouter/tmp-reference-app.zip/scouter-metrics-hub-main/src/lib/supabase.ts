import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Mock data for development
export const mockData = {
  projects: [
    { id: '1', name: 'Projeto Alpha', is_active: true, created_at: '2024-01-01' },
    { id: '2', name: 'Projeto Beta', is_active: true, created_at: '2024-01-15' },
    { id: '3', name: 'Projeto Gamma', is_active: false, created_at: '2024-02-01' },
  ],
  scouters: [
    { id: '1', name: 'Ana Silva', phone: '+5511999999999', active: true },
    { id: '2', name: 'Carlos Santos', phone: '+5511888888888', active: true },
    { id: '3', name: 'Mariana Costa', phone: '+5511777777777', active: true },
    { id: '4', name: 'João Oliveira', phone: '+5511666666666', active: false },
  ],
  leads: Array.from({ length: 150 }, (_, i) => ({
    id: String(i + 1),
    created_at: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
    project_id: String(Math.floor(Math.random() * 3) + 1),
    scouter_id: String(Math.floor(Math.random() * 3) + 1),
    responsavel: `Responsável ${i + 1}`,
    modelo: `Modelo ${i + 1}`,
    idade: Math.floor(Math.random() * 30) + 18,
    has_photo: Math.random() > 0.3,
    confirmed_whatsapp: Math.random() > 0.2,
    contacted: Math.random() > 0.4,
    stage: [
      'novo', 'confirmado', 'interesse', 'agendado', 'compareceu',
      'concluido_pos', 'concluido_neg', 'sem_interesse_def', 'sem_contato', 'sem_interesse_momento'
    ][Math.floor(Math.random() * 10)] as any,
    lat: -23.5505 + (Math.random() - 0.5) * 0.1,
    lng: -46.6333 + (Math.random() - 0.5) * 0.1,
    iqs: Math.random() * 100,
  })),
};