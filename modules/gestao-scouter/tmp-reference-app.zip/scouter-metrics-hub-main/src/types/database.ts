export type LeadStage = 
  | 'novo'
  | 'confirmado'
  | 'interesse'
  | 'agendado'
  | 'compareceu'
  | 'concluido_pos'
  | 'concluido_neg'
  | 'sem_interesse_def'
  | 'sem_contato'
  | 'sem_interesse_momento';

export type PaymentItemType = 'ficha' | 'ajuda_custo';

export type ScouterLevel = 'S1' | 'S2' | 'S3';

export interface Project {
  id: string;
  name: string;
  is_active: boolean;
  created_at: string;
}

export interface Scouter {
  id: string;
  name: string;
  phone?: string;
  active: boolean;
}

export interface ScouterClassification {
  id: string;
  scouter_id: string;
  project_id?: string;
  valor_por_ficha: number;
  ajuda_custo: number;
  meta_fichas: number;
  pct_min_interesse: number;
  pct_max_sem_contato: number;
  pct_min_fotos: number;
  pct_min_agendadas: number;
  pct_min_compareceu: number;
  nivel?: ScouterLevel;
  created_at: string;
}

export interface ProjectIndicatorWeights {
  id: string;
  project_id: string;
  scouter_id?: string;
  peso_foto: number;
  peso_confirmada: number;
  peso_contato: number;
  peso_interesse: number;
  peso_agendado: number;
  peso_compareceu: number;
  peso_concluido_pos: number;
  peso_concluido_neg: number;
  peso_sem_interesse_def: number;
  peso_sem_contato: number;
  peso_sem_interesse_momento: number;
}

export interface ProjectPaymentMultipliers {
  id: string;
  project_id: string;
  stage: LeadStage;
  multiplier: number;
}

export interface Lead {
  id: string;
  created_at: string;
  project_id?: string;
  scouter_id?: string;
  responsavel?: string;
  modelo?: string;
  idade?: number;
  observacoes?: string;
  has_photo: boolean;
  confirmed_whatsapp: boolean;
  contacted: boolean;
  stage: LeadStage;
  lat?: number;
  lng?: number;
  accuracy?: number;
  h3_res7?: string;
  iqs?: number;
  bitrix_id?: string;
  payment_item_id?: string;
  presenca_confirmada?: boolean;
  local_abordagem?: string;
  supervisor?: string;
  valor_ficha?: number;
  data_confirmacao?: string;
}

export interface LeadStageHistory {
  id: string;
  lead_id: string;
  from_stage?: string;
  to_stage: string;
  changed_at: string;
  changed_by?: string;
}

export interface ScouterCheckin {
  id: string;
  scouter_id: string;
  ts: string;
  lat: number;
  lng: number;
  accuracy?: number;
  h3_res7?: string;
}

export interface Payment {
  id: string;
  ref?: string;
  period_start: string;
  period_end: string;
  project_id?: string;
  created_at: string;
  created_by?: string;
  approved_by?: string;
  paid_at?: string;
  paid_by?: string;
  notes?: string;
}

export interface PaymentItem {
  id: string;
  payment_id: string;
  scouter_id?: string;
  type: PaymentItemType;
  lead_id?: string;
  amount: number;
  multiplier?: number;
  base_amount?: number;
  eligible: boolean;
}

export interface KPIData {
  total_fichas: number;
  pct_com_foto: number;
  pct_confirmadas: number;
  pct_conseguiu_contato: number;
  pct_agendadas: number;
  pct_compareceu: number;
  pct_interesse: number;
  pct_concluido_pos: number;
  pct_concluido_neg: number;
  pct_sem_interesse_def: number;
  pct_sem_contato: number;
  pct_sem_interesse_momento: number;
  iqs_medio: number;
}

export interface FilterState {
  dateRange: {
    from: Date;
    to: Date;
  };
  scouterIds: string[];
  projectIds: string[];
}

export interface HeatmapBucket {
  h3_index: string;
  count: number;
  lat: number;
  lng: number;
}