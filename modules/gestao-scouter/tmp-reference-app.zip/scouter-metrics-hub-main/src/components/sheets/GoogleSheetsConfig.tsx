import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, AlertTriangle, RefreshCw, ExternalLink, Key, Sheet } from 'lucide-react';
import { GoogleSheetsService } from '@/services/GoogleSheetsService';
import { useToast } from '@/components/ui/use-toast';

export function GoogleSheetsConfig() {
  const { toast } = useToast();
  const [apiKey, setApiKey] = useState('');
  const [spreadsheetUrl, setSpreadsheetUrl] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');

  useEffect(() => {
    // Check if already configured
    const savedApiKey = GoogleSheetsService.getApiKey();
    const savedSpreadsheetId = GoogleSheetsService.getSpreadsheetId();
    
    if (savedApiKey) {
      setApiKey(savedApiKey);
    }
    
    if (savedSpreadsheetId) {
      setIsConnected(true);
    }
  }, []);

  const handleSaveConfig = async () => {
    if (!apiKey.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira a API Key do Google Sheets",
        variant: "destructive",
      });
      return;
    }

    if (!spreadsheetUrl.trim()) {
      toast({
        title: "Erro", 
        description: "Por favor, insira a URL da planilha",
        variant: "destructive",
      });
      return;
    }

    const spreadsheetId = GoogleSheetsService.extractSpreadsheetId(spreadsheetUrl);
    if (!spreadsheetId) {
      toast({
        title: "Erro",
        description: "URL da planilha inválida. Use o formato: https://docs.google.com/spreadsheets/d/[ID]/edit",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setConnectionStatus('testing');

    // Save configuration
    GoogleSheetsService.saveApiKey(apiKey);
    GoogleSheetsService.saveSpreadsheetId(spreadsheetId);

    // Test connection
    const testResult = await GoogleSheetsService.testConnection();
    
    if (testResult) {
      setConnectionStatus('success');
      setIsConnected(true);
      toast({
        title: "Sucesso",
        description: "Conexão com Google Sheets configurada com sucesso!",
      });
    } else {
      setConnectionStatus('error');
      toast({
        title: "Erro",
        description: "Falha ao conectar com Google Sheets. Verifique a API Key e permissões da planilha.",
        variant: "destructive",
      });
    }

    setIsLoading(false);
  };

  const handleTestConnection = async () => {
    setIsLoading(true);
    setConnectionStatus('testing');

    const testResult = await GoogleSheetsService.testConnection();
    
    if (testResult) {
      setConnectionStatus('success');
      toast({
        title: "Sucesso",
        description: "Conexão testada com sucesso!",
      });
    } else {
      setConnectionStatus('error');
      toast({
        title: "Erro",
        description: "Falha na conexão. Verifique as configurações.",
        variant: "destructive",
      });
    }

    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sheet className="h-5 w-5" />
            Integração Google Sheets
          </CardTitle>
          <CardDescription>
            Configure a conexão com sua planilha do Google Sheets para importar dados automaticamente.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="config" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="config">Configuração</TabsTrigger>
              <TabsTrigger value="instructions">Instruções</TabsTrigger>
            </TabsList>

            <TabsContent value="config" className="space-y-4">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="api-key">Google Sheets API Key</Label>
                  <Input
                    id="api-key"
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="Digite sua API Key do Google Cloud"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="spreadsheet-url">URL da Planilha</Label>
                  <Input
                    id="spreadsheet-url"
                    value={spreadsheetUrl}
                    onChange={(e) => setSpreadsheetUrl(e.target.value)}
                    placeholder="https://docs.google.com/spreadsheets/d/[ID]/edit"
                    className="mt-1"
                  />
                </div>

                <div className="flex gap-2">
                  <Button 
                    onClick={handleSaveConfig}
                    disabled={isLoading}
                    className="flex-1"
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Testando...
                      </>
                    ) : (
                      <>
                        <Key className="mr-2 h-4 w-4" />
                        Salvar Configuração
                      </>
                    )}
                  </Button>

                  {isConnected && (
                    <Button 
                      variant="outline"
                      onClick={handleTestConnection}
                      disabled={isLoading}
                    >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Testar
                    </Button>
                  )}
                </div>

                {/* Status da Conexão */}
                {connectionStatus === 'success' && (
                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>
                      <div className="flex items-center justify-between">
                        <span>Conectado com sucesso ao Google Sheets!</span>
                        <Badge variant="default" className="bg-green-100 text-green-800">
                          Ativo
                        </Badge>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                {connectionStatus === 'error' && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      Falha na conexão. Verifique a API Key e se a planilha está pública ou compartilhada.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </TabsContent>

            <TabsContent value="instructions" className="space-y-4">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Como obter a API Key</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <ol className="list-decimal list-inside space-y-2 text-sm">
                      <li>Acesse o <a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline inline-flex items-center gap-1">Google Cloud Console <ExternalLink className="h-3 w-3" /></a></li>
                      <li>Crie um novo projeto ou selecione um existente</li>
                      <li>Ative a API do Google Sheets na seção "APIs e Serviços"</li>
                      <li>Vá em "Credenciais" e clique em "Criar Credenciais" → "Chave de API"</li>
                      <li>Copie a chave gerada e cole no campo acima</li>
                    </ol>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Configurar Planilha</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <ol className="list-decimal list-inside space-y-2 text-sm">
                      <li>Abra sua planilha no Google Sheets</li>
                      <li>Clique em "Compartilhar" e defina como "Público" ou "Qualquer pessoa com o link"</li>
                      <li>Copie a URL da planilha e cole no campo acima</li>
                      <li>Sua planilha deve ter os cabeçalhos na primeira linha</li>
                    </ol>
                  </CardContent>
                </Card>

                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Segurança:</strong> Para máxima segurança, recomendamos usar a integração nativa do Supabase 
                    para armazenar suas credenciais de forma criptografada.
                  </AlertDescription>
                </Alert>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}