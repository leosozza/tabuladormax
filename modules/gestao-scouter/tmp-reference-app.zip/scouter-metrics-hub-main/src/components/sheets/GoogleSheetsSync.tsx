import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CheckCircle, AlertTriangle, RefreshCw, Download, Eye } from 'lucide-react';
import { GoogleSheetsService } from '@/services/GoogleSheetsService';
import { useToast } from '@/components/ui/use-toast';
import { useLeadsData } from '@/hooks/useLeadsData';

export function GoogleSheetsSync() {
  const { toast } = useToast();
  const { syncData } = useLeadsData();
  const [isLoading, setIsLoading] = useState(false);
  const [previewData, setPreviewData] = useState<any[]>([]);
  const [syncResult, setSyncResult] = useState<{ success: number; errors: string[] } | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  const handlePreview = async () => {
    setIsLoading(true);
    setSyncResult(null);
    
    try {
      const result = await GoogleSheetsService.fetchSheetData();
      
      if (result.success && result.data) {
        const convertedData = GoogleSheetsService.convertToLeads(result.data);
        setPreviewData(convertedData.slice(0, 5)); // Show first 5 rows
        setShowPreview(true);
        
        toast({
          title: "Preview carregado!",
          description: `Foram encontrados ${result.data.length} registros na planilha.`,
        });
      } else {
        toast({
          title: "Erro no preview",
          description: result.error || "Não foi possível carregar os dados da planilha.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro no preview",
        description: "Não foi possível conectar com o Google Sheets.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSync = async () => {
    setIsLoading(true);
    setSyncResult(null);
    
    try {
      await syncData();
      
      setSyncResult({
        success: 1, // We don't have exact count but operation succeeded
        errors: []
      });
      
      toast({
        title: "Sincronização concluída!",
        description: "Dados da planilha foram atualizados com sucesso.",
      });
    } catch (error) {
      setSyncResult({
        success: 0,
        errors: ['Erro ao sincronizar dados da planilha']
      });
      
      toast({
        title: "Erro na sincronização",
        description: "Não foi possível sincronizar os dados.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sincronização Google Sheets</CardTitle>
        <CardDescription>
          Sincronize dados diretamente da planilha configurada
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button
            onClick={handlePreview}
            disabled={isLoading}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Eye className="h-4 w-4" />
            {isLoading ? 'Carregando...' : 'Preview'}
          </Button>
          
          <Button
            onClick={handleSync}
            disabled={isLoading}
            className="flex items-center gap-2"
          >
            {isLoading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            {isLoading ? 'Sincronizando...' : 'Sincronizar Dados'}
          </Button>
        </div>

        {syncResult && (
          <Alert>
            {syncResult.success > 0 ? (
              <CheckCircle className="h-4 w-4" />
            ) : (
              <AlertTriangle className="h-4 w-4" />
            )}
            <AlertDescription>
              {syncResult.success > 0 ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="default">
                      Sucesso
                    </Badge>
                    <span>Dados sincronizados com sucesso!</span>
                  </div>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="destructive">Erro</Badge>
                    <span>Falha na sincronização</span>
                  </div>
                  {syncResult.errors.length > 0 && (
                    <ul className="list-disc list-inside text-sm">
                      {syncResult.errors.map((error, index) => (
                        <li key={index}>{error}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        {showPreview && previewData.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold">Preview dos Dados (primeiras 5 linhas)</h4>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <tr>
                    <TableHead>ID</TableHead>
                    <TableHead>Responsável</TableHead>
                    <TableHead>Modelo</TableHead>
                    <TableHead>Projeto</TableHead>
                    <TableHead>Scouter</TableHead>
                    <TableHead>Estágio</TableHead>
                    <TableHead>Data</TableHead>
                  </tr>
                </TableHeader>
                <TableBody>
                  {previewData.map((row, index) => (
                    <tr key={index}>
                      <TableCell>{row.id}</TableCell>
                      <TableCell>{row.responsavel}</TableCell>
                      <TableCell>{row.modelo}</TableCell>
                      <TableCell>{row.project_id}</TableCell>
                      <TableCell>{row.scouter_id}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {row.stage}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(row.created_at).toLocaleDateString('pt-BR')}
                      </TableCell>
                    </tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}