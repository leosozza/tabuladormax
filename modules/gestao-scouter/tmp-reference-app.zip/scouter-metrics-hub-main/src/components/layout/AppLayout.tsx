import { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { FilterHeader } from './FilterHeader';
import { Analysis } from '@/pages/Analysis';
import { Payments } from '@/pages/Payments';
import { MapView } from '@/pages/MapView';
import { Configuration } from '@/pages/Configuration';
import { FilterState } from '@/types/database';
import { useLeadsData } from '@/hooks/useLeadsData';

export const AppLayout = () => {
  const { scouters, projects } = useLeadsData();
  const [filters, setFilters] = useState<FilterState>({
    dateRange: {
      from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
      to: new Date(),
    },
    scouterIds: [],
    projectIds: [],
  });

  return (
    <div className="min-h-screen bg-gradient-background">
      <div className="flex">
        <Sidebar />
        <div className="flex-1 flex flex-col">
          <FilterHeader 
            filters={filters} 
            onFiltersChange={setFilters}
            scouters={scouters}
            projects={projects}
          />
          <main className="flex-1 p-6">
            <Routes>
              <Route path="/" element={<Navigate to="/analysis" replace />} />
              <Route path="/analysis" element={<Analysis filters={filters} />} />
              <Route path="/payments" element={<Payments filters={filters} />} />
              <Route path="/map" element={<MapView filters={filters} />} />
              <Route path="/configuration" element={<Configuration />} />
            </Routes>
          </main>
        </div>
      </div>
    </div>
  );
};