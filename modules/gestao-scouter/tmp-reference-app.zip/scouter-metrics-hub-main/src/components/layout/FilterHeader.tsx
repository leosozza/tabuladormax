import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { FilterState, Scouter, Project } from '@/types/database';
import { CalendarIcon, Users, FolderOpen, Filter, X } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface FilterHeaderProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  scouters: Scouter[];
  projects: Project[];
}

export const FilterHeader = ({ filters, onFiltersChange, scouters, projects }: FilterHeaderProps) => {
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [scouterPickerOpen, setScouterPickerOpen] = useState(false);
  const [projectPickerOpen, setProjectPickerOpen] = useState(false);

  const selectedScouters = scouters.filter(s => 
    filters.scouterIds.includes(s.id)
  );
  
  const selectedProjects = projects.filter(p => 
    filters.projectIds.includes(p.id)
  );

  const handleScouterToggle = (scouterId: string) => {
    const newScouterIds = filters.scouterIds.includes(scouterId)
      ? filters.scouterIds.filter(id => id !== scouterId)
      : [...filters.scouterIds, scouterId];
    
    onFiltersChange({ ...filters, scouterIds: newScouterIds });
  };

  const handleProjectToggle = (projectId: string) => {
    const newProjectIds = filters.projectIds.includes(projectId)
      ? filters.projectIds.filter(id => id !== projectId)
      : [...filters.projectIds, projectId];
    
    onFiltersChange({ ...filters, projectIds: newProjectIds });
  };

  const clearFilters = () => {
    onFiltersChange({
      dateRange: {
        from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        to: new Date(),
      },
      scouterIds: [],
      projectIds: [],
    });
  };

  const hasActiveFilters = filters.scouterIds.length > 0 || filters.projectIds.length > 0;

  return (
    <Card className="m-6 mb-0 p-4 bg-card shadow-md-primary border-border">
      <div className="flex flex-wrap items-center gap-4">
        <div className="flex items-center space-x-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium text-foreground">Filtros:</span>
        </div>

        {/* Date Range Filter */}
        <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "justify-start text-left font-normal",
                !filters.dateRange && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {filters.dateRange?.from ? (
                filters.dateRange.to ? (
                  <>
                    {format(filters.dateRange.from, "dd/MM/yyyy", { locale: ptBR })} -{" "}
                    {format(filters.dateRange.to, "dd/MM/yyyy", { locale: ptBR })}
                  </>
                ) : (
                  format(filters.dateRange.from, "dd/MM/yyyy", { locale: ptBR })
                )
              ) : (
                <span>Selecionar período</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              initialFocus
              mode="range"
              defaultMonth={filters.dateRange?.from}
              selected={filters.dateRange}
              onSelect={(range) => {
                if (range) {
                  onFiltersChange({
                    ...filters,
                    dateRange: {
                      from: range.from || new Date(),
                      to: range.to || new Date(),
                    },
                  });
                }
              }}
              numberOfMonths={2}
              locale={ptBR}
            />
          </PopoverContent>
        </Popover>

        {/* Scouter Filter */}
        <Popover open={scouterPickerOpen} onOpenChange={setScouterPickerOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="justify-start">
              <Users className="mr-2 h-4 w-4" />
              Scouters
              {selectedScouters.length > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {selectedScouters.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80" align="start">
            <div className="space-y-2">
              <h4 className="font-medium leading-none">Selecionar Scouters</h4>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {scouters.filter(s => s.active).map((scouter) => (
                  <div key={scouter.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`scouter-${scouter.id}`}
                      checked={filters.scouterIds.includes(scouter.id)}
                      onCheckedChange={() => handleScouterToggle(scouter.id)}
                    />
                    <label
                      htmlFor={`scouter-${scouter.id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {scouter.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </PopoverContent>
        </Popover>

        {/* Project Filter */}
        <Popover open={projectPickerOpen} onOpenChange={setProjectPickerOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="justify-start">
              <FolderOpen className="mr-2 h-4 w-4" />
              Projetos
              {selectedProjects.length > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {selectedProjects.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80" align="start">
            <div className="space-y-2">
              <h4 className="font-medium leading-none">Selecionar Projetos</h4>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {projects.filter(p => p.is_active).map((project) => (
                  <div key={project.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`project-${project.id}`}
                      checked={filters.projectIds.includes(project.id)}
                      onCheckedChange={() => handleProjectToggle(project.id)}
                    />
                    <label
                      htmlFor={`project-${project.id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {project.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </PopoverContent>
        </Popover>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="mr-1 h-3 w-3" />
            Limpar filtros
          </Button>
        )}

        {/* Active Filter Tags */}
        <div className="flex flex-wrap gap-2">
          {selectedScouters.map((scouter) => (
            <Badge
              key={scouter.id}
              variant="secondary"
              className="cursor-pointer hover:bg-secondary-hover"
              onClick={() => handleScouterToggle(scouter.id)}
            >
              {scouter.name}
              <X className="ml-1 h-3 w-3" />
            </Badge>
          ))}
          {selectedProjects.map((project) => (
            <Badge
              key={project.id}
              variant="secondary"
              className="cursor-pointer hover:bg-secondary-hover"
              onClick={() => handleProjectToggle(project.id)}
            >
              {project.name}
              <X className="ml-1 h-3 w-3" />
            </Badge>
          ))}
        </div>
      </div>
    </Card>
  );
};