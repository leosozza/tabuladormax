import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Navigation, Layers } from 'lucide-react';
import { Lead } from '@/types/database';

interface MapboxMapProps {
  leads: Lead[];
  onLeadClick?: (lead: Lead) => void;
}

export const MapboxMap = ({ leads, onLeadClick }: MapboxMapProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [mapboxToken, setMapboxToken] = useState<string>('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isInitialized, setIsInitialized] = useState(false);

  // Filter leads with valid coordinates
  const validLeads = leads.filter(lead => 
    lead.lat && lead.lng && !isNaN(lead.lat) && !isNaN(lead.lng) && 
    lead.lat !== 0 && lead.lng !== 0
  );

  const initializeMap = (token: string) => {
    if (!mapContainer.current || !token) return;

    mapboxgl.accessToken = token;
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: [-46.6333, -23.5505], // São Paulo
      zoom: 10,
      projection: 'globe' as any,
    });

    // Add navigation controls
    map.current.addControl(
      new mapboxgl.NavigationControl({
        visualizePitch: true,
      }),
      'top-right'
    );

    map.current.on('load', () => {
      if (!map.current) return;
      
      // Add markers for each lead
      validLeads.forEach((lead) => {
        // Create custom marker element
        const markerElement = document.createElement('div');
        markerElement.className = 'w-6 h-6 bg-primary rounded-full border-2 border-white shadow-lg cursor-pointer hover:scale-110 transition-transform';
        markerElement.title = `${lead.scouter_id} - ${lead.local_abordagem}`;
        
        // Add click handler
        markerElement.addEventListener('click', () => {
          onLeadClick?.(lead);
        });

        const popup = new mapboxgl.Popup({
          offset: 25,
          closeButton: false,
          closeOnClick: false
        }).setHTML(`
          <div class="p-2">
            <p class="font-medium">${lead.scouter_id || 'Scouter não especificado'}</p>
            <p class="text-sm text-gray-600">${lead.local_abordagem || 'Local não especificado'}</p>
            <p class="text-xs text-gray-500">${new Date(lead.created_at).toLocaleDateString('pt-BR')}</p>
            <span class="inline-block mt-1 px-2 py-1 bg-primary text-white text-xs rounded">${lead.stage}</span>
          </div>
        `);

        // Create marker
        new mapboxgl.Marker(markerElement)
          .setLngLat([lead.lng, lead.lat])
          .setPopup(popup)
          .addTo(map.current!);
      });

      // Fit map to show all markers
      if (validLeads.length > 0) {
        const bounds = new mapboxgl.LngLatBounds();
        validLeads.forEach(lead => {
          bounds.extend([lead.lng, lead.lat]);
        });
        map.current.fitBounds(bounds, { padding: 50 });
      }

      setIsInitialized(true);
    });

    map.current.on('error', (e) => {
      console.error('Mapbox error:', e);
      if (e.error.message.includes('token')) {
        setShowTokenInput(true);
        setIsInitialized(false);
      }
    });
  };

  const handleTokenSubmit = () => {
    if (mapboxToken.trim()) {
      localStorage.setItem('mapbox_token', mapboxToken);
      setShowTokenInput(false);
      initializeMap(mapboxToken);
    }
  };

  useEffect(() => {
    // Check for saved token
    const savedToken = localStorage.getItem('mapbox_token');
    if (savedToken) {
      setMapboxToken(savedToken);
      setShowTokenInput(false);
      initializeMap(savedToken);
    }

    return () => {
      map.current?.remove();
    };
  }, []);

  // Update markers when leads change
  useEffect(() => {
    if (map.current && isInitialized) {
      // Remove existing markers and reinitialize
      map.current.remove();
      map.current = null;
      setIsInitialized(false);
      
      const token = localStorage.getItem('mapbox_token');
      if (token) {
        initializeMap(token);
      }
    }
  }, [leads]);

  if (showTokenInput) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MapPin className="h-5 w-5 text-primary" />
            <span>Configuração do Mapa</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Para exibir o mapa, você precisa inserir seu token público do Mapbox.
          </p>
          <p className="text-sm text-muted-foreground">
            Acesse <a href="https://mapbox.com/" target="_blank" rel="noopener noreferrer" className="text-primary underline">mapbox.com</a> e obtenha seu token na seção "Tokens" do dashboard.
          </p>
          <div className="flex space-x-2">
            <Input
              placeholder="Cole seu token público do Mapbox aqui..."
              value={mapboxToken}
              onChange={(e) => setMapboxToken(e.target.value)}
              type="password"
            />
            <Button onClick={handleTokenSubmit} disabled={!mapboxToken.trim()}>
              Conectar
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="relative w-full h-96">
      <div ref={mapContainer} className="absolute inset-0 rounded-lg overflow-hidden" />
      
      {/* Map Statistics */}
      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-md">
        <div className="flex items-center space-x-2 mb-2">
          <MapPin className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">Fichas Mapeadas</span>
        </div>
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-xs text-gray-600">Total:</span>
            <Badge variant="outline" className="text-xs">
              {validLeads.length}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-gray-600">Sem localização:</span>
            <Badge variant="outline" className="text-xs">
              {leads.length - validLeads.length}
            </Badge>
          </div>
        </div>
      </div>

      {/* Loading indicator */}
      {!isInitialized && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted/50 rounded-lg">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="text-sm text-muted-foreground mt-2">Carregando mapa...</p>
          </div>
        </div>
      )}
    </div>
  );
};