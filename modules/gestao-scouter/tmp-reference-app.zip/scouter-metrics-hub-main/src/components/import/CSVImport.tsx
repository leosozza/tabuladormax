import React, { useState } from 'react';
import Papa from 'papaparse';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Upload, FileSpreadsheet, CheckCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { useLeadsData } from '@/hooks/useLeadsData';

interface CSVRow {
  [key: string]: string;
}

interface FieldMapping {
  csvColumn: string;
  dbField: string;
  required: boolean;
}

const DB_FIELDS = [
  { key: 'responsavel', label: 'Responsável', required: true },
  { key: 'modelo', label: 'Nome do Modelo', required: true },
  { key: 'idade', label: 'Idade', required: true },
  { key: 'scouter', label: 'Scouter', required: true },
  { key: 'stage', label: 'Etapa', required: true },
  { key: 'phone', label: 'Telefone/Celular', required: false },
  { key: 'has_photo', label: 'Tem Foto', required: false },
  { key: 'confirmed_whatsapp', label: 'Ficha Confirmada', required: false },
  { key: 'contacted', label: 'Contatado', required: false },
  { key: 'lat', label: 'Latitude', required: false },
  { key: 'lng', label: 'Longitude', required: false },
  { key: 'observacoes', label: 'Observações', required: false },
];

const STAGE_MAPPING: { [key: string]: string } = {
  'Lead a Qualificar': 'novo',
  'StandyBy': 'confirmado',
  'Qualificado': 'interesse',
  'Agendado': 'agendado',
  'Compareceu': 'compareceu',
  'Concluído Positivo': 'concluido_pos',
  'Concluído Negativo': 'concluido_neg',
  'Sem Interesse': 'sem_interesse_def',
  'Sem Contato': 'sem_contato',
};

export function CSVImport() {
  const [file, setFile] = useState<File | null>(null);
  const [csvData, setCsvData] = useState<CSVRow[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [fieldMappings, setFieldMappings] = useState<FieldMapping[]>([]);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ success: number; errors: string[] } | null>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = event.target.files?.[0];
    if (!uploadedFile) return;

    if (!uploadedFile.name.endsWith('.csv')) {
      alert('Por favor, selecione um arquivo CSV válido.');
      return;
    }

    setFile(uploadedFile);
    
    Papa.parse(uploadedFile, {
      header: true,
      delimiter: ';', // Usando ponto e vírgula como delimitador
      skipEmptyLines: true,
      complete: (results) => {
        const data = results.data as CSVRow[];
        setCsvData(data.slice(0, 5)); // Preview primeiras 5 linhas
        
        if (data.length > 0) {
          const csvHeaders = Object.keys(data[0]);
          setHeaders(csvHeaders);
          
          // Auto-mapear campos baseado nos nomes das colunas
          const autoMappings = DB_FIELDS.map(field => {
            const possibleColumns = csvHeaders.filter(header => {
              const headerLower = header.toLowerCase();
              const fieldLower = field.label.toLowerCase();
              
              // Mapeamento específico para alguns campos
              if (field.key === 'responsavel' && headerLower.includes('responsável')) return true;
              if (field.key === 'modelo' && headerLower.includes('nome do modelo')) return true;
              if (field.key === 'idade' && headerLower.includes('idade')) return true;
              if (field.key === 'scouter' && headerLower === 'scouter') return true;
              if (field.key === 'stage' && headerLower === 'etapa') return true;
              if (field.key === 'phone' && (headerLower.includes('celular') || headerLower.includes('telefone'))) return true;
              if (field.key === 'has_photo' && (headerLower.includes('foto') || headerLower.includes('cadastro existe foto'))) return true;
              if (field.key === 'confirmed_whatsapp' && headerLower.includes('ficha confirmada')) return true;
              if (field.key === 'observacoes' && headerLower.includes('observaç')) return true;
              
              return false;
            });
            
            return {
              csvColumn: possibleColumns[0] || '',
              dbField: field.key,
              required: field.required
            };
          });
          
          setFieldMappings(autoMappings);
        }
      },
      error: (error) => {
        console.error('Erro ao processar CSV:', error);
        alert('Erro ao processar arquivo CSV.');
      }
    });
  };

  const updateFieldMapping = (dbField: string, csvColumn: string) => {
    setFieldMappings(prev => 
      prev.map(mapping => 
        mapping.dbField === dbField 
          ? { ...mapping, csvColumn }
          : mapping
      )
    );
  };

  const validateMappings = () => {
    const errors: string[] = [];
    
    fieldMappings.forEach(mapping => {
      if (mapping.required && !mapping.csvColumn) {
        const field = DB_FIELDS.find(f => f.key === mapping.dbField);
        errors.push(`Campo obrigatório "${field?.label}" não foi mapeado.`);
      }
    });
    
    return errors;
  };

  const processImport = () => {
    if (!file) return;
    
    const validationErrors = validateMappings();
    if (validationErrors.length > 0) {
      alert('Corrija os erros de mapeamento antes de importar:\n' + validationErrors.join('\n'));
      return;
    }
    
    setImporting(true);
    
    Papa.parse(file, {
      header: true,
      delimiter: ';',
      skipEmptyLines: true,
      complete: (results) => {
        const data = results.data as CSVRow[];
        const errors: string[] = [];
        let successCount = 0;
        
        data.forEach((row, index) => {
          try {
            // Mapear dados da linha CSV para nosso formato
            const leadData: any = {};
            
            fieldMappings.forEach(mapping => {
              if (mapping.csvColumn && row[mapping.csvColumn]) {
                let value = row[mapping.csvColumn];
                
                // Processamento específico por tipo de campo
                switch (mapping.dbField) {
                  case 'idade':
                    leadData.idade = parseInt(value) || 0;
                    break;
                  case 'stage':
                    leadData.stage = STAGE_MAPPING[value] || 'novo';
                    break;
                  case 'has_photo':
                    leadData.has_photo = value.toLowerCase().includes('sim') || value.includes('✳ Sim') || value.includes('SIM');
                    break;
                  case 'confirmed_whatsapp':
                    leadData.confirmed_whatsapp = value.toLowerCase().includes('sim') || value === 'Y';
                    break;
                  case 'contacted':
                    leadData.contacted = value.toLowerCase().includes('sim') || value === 'true';
                    break;
                  default:
                    leadData[mapping.dbField] = value;
                }
              }
            });
            
            // Valores padrão
            leadData.id = String(Date.now() + index);
            leadData.created_at = new Date().toISOString();
            leadData.project_id = '1'; // Projeto padrão
            leadData.scouter_id = '1'; // Scouter padrão por enquanto
            leadData.lat = -23.5505 + (Math.random() - 0.5) * 0.1;
            leadData.lng = -46.6333 + (Math.random() - 0.5) * 0.1;
            leadData.iqs = Math.random() * 100;
            
            // Validações básicas
            if (!leadData.responsavel || !leadData.modelo) {
              errors.push(`Linha ${index + 2}: Responsável e Nome do Modelo são obrigatórios.`);
              return;
            }
            
            // Para esta implementação, apenas conta como sucesso
            // Em produção, seria salvo no banco
            successCount++;
            
          } catch (error) {
            errors.push(`Linha ${index + 2}: Erro ao processar dados - ${error}`);
          }
        });
        
        setImportResult({
          success: successCount,
          errors: errors.slice(0, 10) // Mostrar apenas os primeiros 10 erros
        });
        
        setImporting(false);
      },
      error: (error) => {
        console.error('Erro ao processar CSV:', error);
        setImportResult({
          success: 0,
          errors: ['Erro ao processar arquivo CSV.']
        });
        setImporting(false);
      }
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            Importar Planilha de Leads
          </CardTitle>
          <CardDescription>
            Faça upload de um arquivo CSV para importar leads em lote. 
            O arquivo deve usar ponto e vírgula (;) como separador.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="csv-file">Arquivo CSV</Label>
            <Input
              id="csv-file"
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="mt-1"
            />
          </div>

          {file && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Arquivo carregado: {file.name} ({headers.length} colunas, {csvData.length}+ registros)
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {headers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Mapeamento de Campos</CardTitle>
            <CardDescription>
              Configure quais colunas da planilha correspondem aos campos do sistema.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {DB_FIELDS.map(field => {
                const mapping = fieldMappings.find(m => m.dbField === field.key);
                return (
                  <div key={field.key} className="flex items-center gap-4">
                    <div className="flex-1">
                      <Label className="flex items-center gap-2">
                        {field.label}
                        {field.required && <Badge variant="destructive" className="text-xs">Obrigatório</Badge>}
                      </Label>
                    </div>
                    <div className="flex-1">
                      <Select
                        value={mapping?.csvColumn || ''}
                        onValueChange={(value) => updateFieldMapping(field.key, value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione a coluna CSV" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">-- Não mapear --</SelectItem>
                          {headers.map(header => (
                            <SelectItem key={header} value={header}>
                              {header}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {csvData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Preview dos Dados</CardTitle>
            <CardDescription>
              Primeiras 5 linhas do arquivo CSV (total: {csvData.length}+ registros)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-auto max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    {headers.slice(0, 8).map(header => (
                      <TableHead key={header} className="min-w-[120px]">
                        {header}
                      </TableHead>
                    ))}
                    {headers.length > 8 && (
                      <TableHead>... e mais {headers.length - 8} colunas</TableHead>
                    )}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {csvData.map((row, index) => (
                    <TableRow key={index}>
                      {headers.slice(0, 8).map(header => (
                        <TableCell key={header} className="max-w-[150px] truncate">
                          {row[header]}
                        </TableCell>
                      ))}
                      {headers.length > 8 && <TableCell>...</TableCell>}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {headers.length > 0 && (
        <Card>
          <CardContent className="pt-6">
            <Button 
              onClick={processImport}
              disabled={importing || headers.length === 0}
              className="w-full"
              size="lg"
            >
              {importing ? (
                <>
                  <Upload className="mr-2 h-4 w-4 animate-spin" />
                  Importando...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Importar {csvData.length}+ Registros
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {importResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {importResult.success > 0 ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-red-600" />
              )}
              Resultado da Importação
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <Badge variant="default" className="bg-green-100 text-green-800">
                {importResult.success} registros importados
              </Badge>
              {importResult.errors.length > 0 && (
                <Badge variant="destructive">
                  {importResult.errors.length} erros
                </Badge>
              )}
            </div>

            {importResult.errors.length > 0 && (
              <div>
                <Label>Erros encontrados:</Label>
                <div className="mt-2 space-y-1">
                  {importResult.errors.map((error, index) => (
                    <Alert key={index} variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-sm">{error}</AlertDescription>
                    </Alert>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}