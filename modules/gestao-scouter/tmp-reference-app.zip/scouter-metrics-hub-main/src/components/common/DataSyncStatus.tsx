import React from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, AlertTriangle, CheckCircle, Clock, Settings } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface DataSyncStatusProps {
  isConfigured: boolean;
  isLoading: boolean;
  error: string | null;
  lastSync: Date | null;
  onSync: () => void;
  onConfigure?: () => void;
}

export function DataSyncStatus({ 
  isConfigured, 
  isLoading, 
  error, 
  lastSync, 
  onSync, 
  onConfigure 
}: DataSyncStatusProps) {
  if (!isConfigured) {
    return (
      <Alert className="mb-6">
        <Settings className="h-4 w-4" />
        <AlertDescription className="flex items-center justify-between">
          <span>Google Sheets não configurado. Usando dados fictícios para demonstração.</span>
          {onConfigure && (
            <Button variant="outline" size="sm" onClick={onConfigure}>
              <Settings className="mr-2 h-4 w-4" />
              Configurar
            </Button>
          )}
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="mb-6 flex items-center justify-between p-4 bg-muted/30 rounded-lg border">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          {isLoading ? (
            <RefreshCw className="h-4 w-4 animate-spin text-primary" />
          ) : error ? (
            <AlertTriangle className="h-4 w-4 text-destructive" />
          ) : (
            <CheckCircle className="h-4 w-4 text-green-600" />
          )}
          
          <span className="text-sm font-medium">
            {isLoading ? 'Sincronizando...' : error ? 'Erro na sincronização' : 'Dados sincronizados'}
          </span>
        </div>

        {lastSync && !isLoading && (
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>
              há {formatDistanceToNow(lastSync, { locale: ptBR })}
            </span>
          </div>
        )}

        <Badge variant={error ? "destructive" : isLoading ? "secondary" : "default"}>
          {error ? 'Erro' : isLoading ? 'Carregando' : 'Online'}
        </Badge>
      </div>

      <Button 
        variant="outline" 
        size="sm" 
        onClick={onSync}
        disabled={isLoading}
      >
        {isLoading ? (
          <>
            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
            Sincronizando...
          </>
        ) : (
          <>
            <RefreshCw className="mr-2 h-4 w-4" />
            Sincronizar
          </>
        )}
      </Button>
    </div>
  );
}