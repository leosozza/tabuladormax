import { useState, useEffect } from 'react';
import { GoogleSheetsService } from '@/services/GoogleSheetsService';
import { Lead, Scouter, Project } from '@/types/database';

interface LeadsDataState {
  leads: Lead[];
  scouters: Scouter[];
  projects: Project[];
  isLoading: boolean;
  error: string | null;
  lastSync: Date | null;
}

export function useLeadsData() {
  const [data, setData] = useState<LeadsDataState>({
    leads: [],
    scouters: [],
    projects: [],
    isLoading: true,
    error: null,
    lastSync: null,
  });

  const syncData = async () => {
    setData(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      // Use the hardcoded spreadsheet URL from the user
      const spreadsheetId = '14l4A_BOFZM-TwLuam-bKzUgInNAA7fOCeamdkE1nt_o';
      const range = 'A:Z'; // Get all columns
      
      // Save the spreadsheet ID to the service
      GoogleSheetsService.saveSpreadsheetId(spreadsheetId);
      
      const result = await GoogleSheetsService.fetchSheetData(range);
      
      if (result.success && result.data) {
        const convertedLeads = GoogleSheetsService.convertToLeads(result.data);
        
        // Extract unique scouters and projects from the leads data
        const uniqueScouters = Array.from(
          new Set(convertedLeads.map(lead => lead.scouter_id).filter(Boolean))
        ).map((scouterId, index) => ({
          id: String(index + 1),
          name: scouterId as string,
          phone: '',
          active: true
        }));

        const uniqueProjects = Array.from(
          new Set(convertedLeads.map(lead => lead.project_id).filter(Boolean))
        ).map((projectId, index) => ({
          id: String(index + 1),
          name: projectId as string,
          is_active: true,
          created_at: new Date().toISOString()
        }));
        
        // Update all data
        setData(prev => ({
          ...prev,
          leads: convertedLeads,
          scouters: uniqueScouters,
          projects: uniqueProjects,
          isLoading: false,
          lastSync: new Date(),
        }));
      } else {
        setData(prev => ({
          ...prev,
          isLoading: false,
          error: result.error || 'Erro ao sincronizar dados da planilha',
        }));
      }
    } catch (error) {
      console.error('Erro ao buscar dados da planilha:', error);
      setData(prev => ({
        ...prev,
        isLoading: false,
        error: 'Erro ao conectar com Google Sheets. Verifique a configuração.',
      }));
    }
  };

  // Auto-sync on mount to always load real data
  useEffect(() => {
    syncData();
  }, []);

  return {
    ...data,
    syncData,
    isConfigured: true, // Always configured since we're using the hardcoded spreadsheet
  };
}